// WhatsApp & n8n Automation Hooks

export async function triggerN8nWebhook(data: {
  event: string;
  payload: Record<string, unknown>;
}) {
  const webhookUrl = process.env.N8N_CONTACT_WEBHOOK_URL;
  if (!webhookUrl) return;
  try {
    await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...data, timestamp: new Date().toISOString() }),
    });
  } catch (err) {
    console.error('n8n webhook error:', err);
  }
}

export async function sendWhatsAppNotification(message: string, to?: string) {
  const webhookUrl = process.env.N8N_WHATSAPP_WEBHOOK_URL;
  const recipient = to || process.env.WHATSAPP_BUSINESS_PHONE_ID;
  if (!webhookUrl) return;
  try {
    await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ to: recipient, message, timestamp: new Date().toISOString() }),
    });
  } catch (err) {
    console.error('WhatsApp notification error:', err);
  }
}
