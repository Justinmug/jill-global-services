const API_KEY = process.env.AIRTABLE_API_KEY!;
const BASE_ID = process.env.AIRTABLE_BASE_ID!;
const LEADS_TABLE = process.env.AIRTABLE_LEADS_TABLE_ID!;

async function airtableRequest(method: string, path: string, body?: object) {
  const res = await fetch(`https://api.airtable.com/v0/${BASE_ID}/${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Airtable ${method} failed: ${err}`);
  }
  return res.json();
}

export async function createLead(lead: {
  name?: string; email?: string; phone?: string;
  service?: string; location?: string; budget?: string;
  message?: string; source?: string;
}) {
  return airtableRequest('POST', LEADS_TABLE, {
    fields: {
      Name: lead.name || '',
      Email: lead.email || '',
      Phone: lead.phone || '',
      Service: lead.service || '',
      Location: lead.location || '',
      Budget: lead.budget || '',
      Message: lead.message || '',
      Source: lead.source || 'Website',
      Status: 'New',
      'Created At': new Date().toISOString(),
    },
  });
}

export async function getLeads() {
  return airtableRequest('GET', `${LEADS_TABLE}?sort%5B0%5D%5Bfield%5D=Created+At&sort%5B0%5D%5Bdirection%5D=desc&maxRecords=200`);
}

export async function updateLead(recordId: string, fields: Record<string, unknown>) {
  return airtableRequest('PATCH', `${LEADS_TABLE}/${recordId}`, { fields });
}
