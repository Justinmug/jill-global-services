import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'jill-global-jwt-secret';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'Eguolo222%';

export function verifyAdminPassword(password: string): boolean {
  return password === ADMIN_PASSWORD;
}

export function generateAdminToken(): string {
  return jwt.sign({ role: 'admin', iat: Date.now() }, JWT_SECRET, { expiresIn: '8h' });
}

export function verifyAdminToken(token: string): boolean {
  try {
    jwt.verify(token, JWT_SECRET);
    return true;
  } catch {
    return false;
  }
}

export function getTokenFromRequest(req: { headers: { authorization?: string } }): string | null {
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith('Bearer ')) return null;
  return auth.slice(7);
}
