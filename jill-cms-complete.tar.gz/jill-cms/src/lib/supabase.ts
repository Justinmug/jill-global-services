import { createClient } from '@supabase/supabase-js';

const url = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;

// Public client (browser-safe)
export const supabase = createClient(url, anonKey);

// Server-side admin client
export const supabaseAdmin = () => createClient(url, serviceKey, {
  auth: { autoRefreshToken: false, persistSession: false }
});

// ===================== CONTENT FETCHERS =====================

export async function getSiteSettings() {
  const { data } = await supabase.from('site_settings').select('key, value');
  if (!data) return {};
  return data.reduce((acc: Record<string, any>, row) => {
    acc[row.key] = row.value;
    return acc;
  }, {});
}

export async function getHeroSection() {
  const { data } = await supabase.from('hero_section').select('*').single();
  return data;
}

export async function getAboutSection() {
  const { data } = await supabase.from('about_section').select('*').single();
  return data;
}

export async function getServices() {
  const { data } = await supabase.from('services').select('*')
    .eq('is_active', true).order('sort_order');
  return data || [];
}

export async function getPortfolio(featured?: boolean) {
  let q = supabase.from('portfolio_projects').select('*').eq('is_active', true).order('sort_order');
  if (featured) q = q.eq('is_featured', true);
  const { data } = await q;
  return data || [];
}

export async function getGallery() {
  const { data } = await supabase.from('gallery_images').select('*')
    .eq('is_active', true).order('sort_order');
  return data || [];
}

export async function getTeam() {
  const { data } = await supabase.from('team_members').select('*')
    .eq('is_active', true).order('sort_order');
  return data || [];
}

export async function getTestimonials() {
  const { data } = await supabase.from('testimonials').select('*')
    .eq('is_active', true).order('sort_order');
  return data || [];
}

export async function getBlogPosts(limit?: number) {
  let q = supabase.from('blog_posts').select('*').eq('is_published', true)
    .order('published_at', { ascending: false });
  if (limit) q = q.limit(limit);
  const { data } = await q;
  return data || [];
}

export async function getBlogPost(slug: string) {
  const { data } = await supabase.from('blog_posts').select('*')
    .eq('slug', slug).eq('is_published', true).single();
  return data;
}

export async function getFaqs() {
  const { data } = await supabase.from('faq_items').select('*')
    .eq('is_active', true).order('sort_order');
  return data || [];
}

export async function getJobs() {
  const { data } = await supabase.from('job_openings').select('*')
    .eq('is_active', true).order('sort_order');
  return data || [];
}

// ===================== IMAGE UPLOAD =====================

export async function uploadImage(file: File, folder: string = 'general') {
  const ext = file.name.split('.').pop();
  const filename = `${folder}/${Date.now()}-${Math.random().toString(36).substr(2, 9)}.${ext}`;
  const { data, error } = await supabaseAdmin().storage
    .from('site-images').upload(filename, file, { upsert: true });
  if (error) throw error;
  const { data: urlData } = supabaseAdmin().storage.from('site-images').getPublicUrl(filename);
  return urlData.publicUrl;
}

// Server-side image upload from Buffer
export async function uploadImageBuffer(buffer: Buffer, filename: string, mimeType: string) {
  const { data, error } = await supabaseAdmin().storage
    .from('site-images').upload(filename, buffer, { contentType: mimeType, upsert: true });
  if (error) throw error;
  const { data: urlData } = supabaseAdmin().storage.from('site-images').getPublicUrl(filename);
  return urlData.publicUrl;
}
