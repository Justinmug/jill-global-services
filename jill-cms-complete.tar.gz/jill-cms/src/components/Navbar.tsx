import { useState } from 'react';
import Link from 'next/link';

export default function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <nav className="fixed top-0 w-full z-50 bg-navy/95 backdrop-blur-sm border-b border-gold/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gold flex items-center justify-center">
              <span className="text-navy font-black text-lg">J</span>
            </div>
            <div>
              <div className="text-white font-bold text-lg leading-tight">Jill Global</div>
              <div className="text-gold text-xs tracking-widest uppercase">Services Ltd</div>
            </div>
          </Link>

          {/* Desktop links */}
          <div className="hidden md:flex items-center gap-8">
            {['Home', 'About', 'Services', 'Projects', 'Contact'].map((item) => (
              <a
                key={item}
                href={`#${item.toLowerCase()}`}
                className="text-white/80 hover:text-gold transition-colors text-sm font-medium tracking-wide"
              >
                {item}
              </a>
            ))}
          </div>

          {/* CTA */}
          <div className="hidden md:flex items-center gap-4">
            <a
              href="https://wa.me/2348128162273"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-gold text-navy px-5 py-2 rounded font-semibold text-sm hover:bg-gold/90 transition-colors"
            >
              Get a Quote
            </a>
          </div>

          {/* Mobile menu button */}
          <button
            className="md:hidden text-white p-2"
            onClick={() => setOpen(!open)}
            aria-label="Toggle menu"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {open ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>

        {/* Mobile menu */}
        {open && (
          <div className="md:hidden py-4 border-t border-gold/20">
            {['Home', 'About', 'Services', 'Projects', 'Contact'].map((item) => (
              <a
                key={item}
                href={`#${item.toLowerCase()}`}
                className="block py-3 text-white/80 hover:text-gold transition-colors font-medium"
                onClick={() => setOpen(false)}
              >
                {item}
              </a>
            ))}
            <a
              href="https://wa.me/2348128162273"
              target="_blank"
              rel="noopener noreferrer"
              className="mt-4 block text-center bg-gold text-navy py-3 rounded font-semibold"
            >
              Get a Quote
            </a>
          </div>
        )}
      </div>
    </nav>
  );
}
