import { useState, useEffect, useRef } from 'react';
import Head from 'next/head';

// ─── Types ───────────────────────────────────────────────────
type Panel = 'dashboard' | 'branding' | 'hero' | 'about' | 'services' | 'portfolio' | 'gallery' | 'team' | 'testimonials' | 'blog' | 'faq' | 'jobs' | 'social' | 'contact' | 'leads' | 'settings';

// ─── Helpers ─────────────────────────────────────────────────
const SIDEBAR_ITEMS: { id: Panel; label: string; icon: string; section?: string; badge?: string }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: '⊞', section: 'Overview' },
  { id: 'branding', label: 'Logo & Branding', icon: '◈', section: 'Site Content' },
  { id: 'hero', label: 'Hero Section', icon: '◻', },
  { id: 'about', label: 'About Page', icon: '◉' },
  { id: 'services', label: 'Services', icon: '✦' },
  { id: 'portfolio', label: 'Portfolio', icon: '⬡' },
  { id: 'gallery', label: 'Gallery', icon: '◫' },
  { id: 'team', label: 'Team Members', icon: '◒' },
  { id: 'testimonials', label: 'Testimonials', icon: '❝' },
  { id: 'blog', label: 'Blog Posts', icon: '✎' },
  { id: 'faq', label: 'FAQ', icon: '?' },
  { id: 'jobs', label: 'Careers / Jobs', icon: '⚐' },
  { id: 'social', label: 'Social Media', icon: '◆', section: 'Settings' },
  { id: 'contact', label: 'Contact Info', icon: '◎' },
  { id: 'leads', label: 'Leads / CRM', icon: '⊹', badge: 'NEW' },
  { id: 'settings', label: 'Automation', icon: '⚙' },
];

function useAdminAPI(token: string) {
  const headers = { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` };
  
  async function get(table: string) {
    const res = await fetch(`/api/content/${table}`, { headers });
    return res.json();
  }
  async function update(table: string, data: any) {
    const res = await fetch(`/api/content/${table}`, { method: 'PATCH', headers, body: JSON.stringify(data) });
    return res.json();
  }
  async function create(table: string, data: any) {
    const res = await fetch(`/api/content/${table}`, { method: 'POST', headers, body: JSON.stringify(data) });
    return res.json();
  }
  async function del(table: string, id: string) {
    const res = await fetch(`/api/content/${table}?id=${id}`, { method: 'DELETE', headers });
    return res.json();
  }
  async function getSettings() {
    const res = await fetch('/api/settings', { headers });
    return res.json();
  }
  async function updateSettings(key: string, value: object) {
    const res = await fetch('/api/settings', { method: 'PUT', headers, body: JSON.stringify({ key, value }) });
    return res.json();
  }
  async function uploadImage(file: File, folder: string) {
    return new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = async (e) => {
        const imageData = e.target?.result as string;
        const res = await fetch('/api/upload', {
          method: 'POST', headers,
          body: JSON.stringify({ imageData, filename: file.name, mimeType: file.type, folder }),
        });
        const data = await res.json();
        if (data.url) resolve(data.url);
        else reject(new Error(data.error || 'Upload failed'));
      };
      reader.readAsDataURL(file);
    });
  }
  
  return { get, update, create, del, getSettings, updateSettings, uploadImage };
}

// ─── Image Upload Component ──────────────────────────────────
function ImageUpload({ currentUrl, onUpload, folder = 'general', label = 'Upload Image' }: { currentUrl?: string; onUpload: (url: string) => void; folder?: string; label?: string }) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [preview, setPreview] = useState(currentUrl || '');

  const handleFile = async (file: File) => {
    setUploading(true);
    try {
      const reader = new FileReader();
      reader.onload = async (e) => {
        const imageData = e.target?.result as string;
        const res = await fetch('/api/upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ imageData, filename: file.name, mimeType: file.type, folder }),
        });
        const data = await res.json();
        if (data.url) { setPreview(data.url); onUpload(data.url); }
      };
      reader.readAsDataURL(file);
    } finally { setUploading(false); }
  };

  return (
    <div style={{ marginBottom: '1.25rem' }}>
      <label style={{ display: 'block', fontSize: '.82rem', fontWeight: 600, color: '#3a5546', marginBottom: '.5rem' }}>{label}</label>
      <div style={{ display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
        {preview && <img src={preview} alt="" style={{ width: 80, height: 80, borderRadius: 8, objectFit: 'cover', border: '1px solid #d0e8dc' }} />}
        <div style={{ flex: 1 }}>
          <input type="text" value={preview} onChange={e => { setPreview(e.target.value); onUpload(e.target.value); }} placeholder="https://... or upload below" style={{ width: '100%', padding: '.7rem 1rem', border: '1px solid #d0e8dc', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.875rem', marginBottom: '.5rem' }} />
          <button type="button" onClick={() => inputRef.current?.click()} disabled={uploading} style={{ padding: '.5rem 1rem', borderRadius: 8, border: '1px dashed #d0e8dc', background: '#f8faf9', fontSize: '.82rem', cursor: 'pointer', color: '#005C3D', fontWeight: 600 }}>
            {uploading ? '⏳ Uploading...' : '📤 Upload Image'}
          </button>
          <input ref={inputRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={e => { const f = e.target.files?.[0]; if (f) handleFile(f); }} />
        </div>
      </div>
    </div>
  );
}

// ─── Field Component ─────────────────────────────────────────
function Field({ label, type = 'text', value, onChange, rows, placeholder }: { label: string; type?: string; value: string; onChange: (v: string) => void; rows?: number; placeholder?: string }) {
  const style = { width: '100%', padding: '.82rem 1.1rem', border: '1.5px solid #d0e8dc', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.905rem', color: '#152e22', background: '#f8faf9', outline: 'none' };
  return (
    <div style={{ marginBottom: '1.25rem' }}>
      <label style={{ display: 'block', fontSize: '.82rem', fontWeight: 600, color: '#3a5546', marginBottom: '.5rem' }}>{label}</label>
      {type === 'textarea' ? <textarea rows={rows || 3} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} style={{ ...style, resize: 'vertical' }} /> : <input type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} style={style} />}
    </div>
  );
}

// ─── ADMIN DASHBOARD ─────────────────────────────────────────
export default function AdminDashboard() {
  const [authed, setAuthed] = useState(false);
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState('');
  const [token, setToken] = useState('');
  const [panel, setPanel] = useState<Panel>('dashboard');
  const [toast, setToast] = useState('');
  const [loading, setLoading] = useState(false);
  
  // Content state
  const [heroData, setHeroData] = useState<any>({});
  const [aboutData, setAboutData] = useState<any>({});
  const [settings, setSettings] = useState<Record<string, any>>({});
  const [services, setServices] = useState<any[]>([]);
  const [portfolio, setPortfolio] = useState<any[]>([]);
  const [gallery, setGallery] = useState<any[]>([]);
  const [team, setTeam] = useState<any[]>([]);
  const [testimonials, setTestimonials] = useState<any[]>([]);
  const [blog, setBlog] = useState<any[]>([]);
  const [faqs, setFaqs] = useState<any[]>([]);
  const [jobs, setJobs] = useState<any[]>([]);
  const [leads, setLeads] = useState<any[]>([]);

  const showToast = (msg: string) => { setToast(msg); setTimeout(() => setToast(''), 3000); };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/auth', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password }) });
    const data = await res.json();
    if (data.token) { setToken(data.token); setAuthed(true); localStorage.setItem('cms_token', data.token); }
    else setAuthError('Invalid password. Please try again.');
  };

  useEffect(() => {
    const saved = localStorage.getItem('cms_token');
    if (saved) { setToken(saved); setAuthed(true); }
  }, []);

  useEffect(() => {
    if (!authed || !token) return;
    const api = useAdminAPI(token);
    setLoading(true);
    Promise.allSettled([
      api.get('hero_section').then(d => setHeroData(d?.[0] || {})),
      api.get('about_section').then(d => setAboutData(d?.[0] || {})),
      api.getSettings().then(setSettings),
      api.get('services').then(setServices),
      api.get('portfolio_projects').then(setPortfolio),
      api.get('gallery_images').then(setGallery),
      api.get('team_members').then(setTeam),
      api.get('testimonials').then(setTestimonials),
      api.get('blog_posts').then(setBlog),
      api.get('faq_items').then(setFaqs),
      api.get('job_openings').then(setJobs),
      fetch('/api/leads', { headers: { Authorization: `Bearer ${token}` } }).then(r => r.json()).then(setLeads),
    ]).finally(() => setLoading(false));
  }, [authed, token]);

  const api = token ? useAdminAPI(token) : null;

  async function save(table: string, data: any) {
    if (!api) return;
    await api.update(table, data);
    showToast('✓ Saved successfully!');
  }

  async function saveSettings(key: string, value: object) {
    if (!api) return;
    await api.updateSettings(key, value);
    showToast('✓ Settings saved!');
  }

  // ─ LOGIN SCREEN ─
  if (!authed) {
    return (
      <>
        <Head><title>Admin Login — Jill Global CMS</title></Head>
        <div style={{ minHeight: '100vh', background: '#003d28', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '2rem', fontFamily: 'Outfit,sans-serif' }}>
          <div style={{ background: '#fff', borderRadius: 18, padding: '3rem', width: '100%', maxWidth: 400, boxShadow: '0 24px 60px rgba(0,0,0,.3)' }}>
            <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
              <div style={{ width: 64, height: 64, background: 'linear-gradient(135deg,#C89A1C,#a07810)', borderRadius: 16, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Playfair Display,serif', fontWeight: 700, fontSize: '1.5rem', color: '#fff', margin: '0 auto 1rem' }}>JG</div>
              <h1 style={{ fontFamily: 'Playfair Display,serif', fontSize: '1.9rem', marginBottom: '.4rem' }}>CMS Dashboard</h1>
              <p style={{ color: '#6a8a7a', fontSize: '.875rem' }}>Jill Global Services Ltd</p>
            </div>
            <form onSubmit={handleLogin}>
              <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Enter admin password" onKeyDown={e => e.key === 'Enter' && handleLogin(e as any)}
                style={{ width: '100%', padding: '1rem 1.25rem', border: '2px solid #d0e8dc', borderRadius: 10, fontFamily: 'Outfit,sans-serif', fontSize: '.95rem', outline: 'none', marginBottom: '.75rem' }} />
              {authError && <p style={{ color: 'red', fontSize: '.82rem', marginBottom: '.75rem' }}>{authError}</p>}
              <button type="submit" style={{ width: '100%', padding: '1rem', background: 'linear-gradient(135deg,#C89A1C,#a07810)', color: '#fff', border: 'none', borderRadius: 10, fontFamily: 'Outfit,sans-serif', fontSize: '.95rem', fontWeight: 700, cursor: 'pointer' }}>Sign In</button>
            </form>
            <div style={{ marginTop: '1.5rem', textAlign: 'center' }}>
              <a href="/" style={{ color: '#6a8a7a', fontSize: '.82rem', textDecoration: 'none' }}>← Back to Website</a>
            </div>
          </div>
        </div>
      </>
    );
  }

  // ─ MAIN DASHBOARD ─
  const branding = settings?.branding || {};
  const contact = settings?.contact || {};
  const social = settings?.social || {};
  const automation = settings?.automation || {};

  return (
    <>
      <Head><title>CMS Dashboard — Jill Global Services</title></Head>
      <div style={{ display: 'grid', gridTemplateColumns: '260px 1fr', minHeight: '100vh', fontFamily: 'Outfit,sans-serif', background: '#f0f4f0' }}>
        
        {/* SIDEBAR */}
        <div style={{ background: '#003d28', overflowY: 'auto', padding: '1.5rem 1rem', display: 'flex', flexDirection: 'column' }}>
          {/* Logo */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '.75rem', padding: '.5rem .5rem 1.5rem', borderBottom: '1px solid rgba(255,255,255,.1)', marginBottom: '1rem' }}>
            <div style={{ width: 38, height: 38, background: 'linear-gradient(135deg,#C89A1C,#a07810)', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Playfair Display,serif', fontWeight: 700, color: '#fff' }}>JG</div>
            <div><div style={{ color: '#fff', fontWeight: 700, fontSize: '.9rem', lineHeight: 1.2 }}>Jill Global CMS</div><div style={{ color: 'rgba(255,255,255,.4)', fontSize: '.65rem', letterSpacing: '.08em' }}>Content Management</div></div>
          </div>
          
          {SIDEBAR_ITEMS.map(item => (
            <div key={item.id}>
              {item.section && <div style={{ fontSize: '.62rem', fontWeight: 700, letterSpacing: '.2em', textTransform: 'uppercase', color: 'rgba(255,255,255,.3)', padding: '.5rem .75rem', margin: '.75rem 0 .4rem' }}>{item.section}</div>}
              <div onClick={() => setPanel(item.id)} style={{ display: 'flex', alignItems: 'center', gap: '.75rem', padding: '.7rem .85rem', borderRadius: 8, cursor: 'pointer', background: panel === item.id ? 'rgba(255,255,255,.12)' : 'transparent', transition: 'all .2s', position: 'relative' }}
                onMouseEnter={e => { if (panel !== item.id) (e.currentTarget as any).style.background = 'rgba(255,255,255,.07)'; }}
                onMouseLeave={e => { if (panel !== item.id) (e.currentTarget as any).style.background = 'transparent'; }}>
                <span style={{ fontSize: '1rem', color: panel === item.id ? '#C89A1C' : 'rgba(255,255,255,.5)', minWidth: 20, textAlign: 'center' }}>{item.icon}</span>
                <span style={{ fontSize: '.875rem', color: panel === item.id ? '#fff' : 'rgba(255,255,255,.65)', fontWeight: 500 }}>{item.label}</span>
                {item.badge && <span style={{ position: 'absolute', right: '.75rem', background: '#C89A1C', color: '#fff', fontSize: '.6rem', fontWeight: 700, padding: '.1rem .45rem', borderRadius: 100 }}>{item.badge}</span>}
              </div>
            </div>
          ))}
          
          <div style={{ marginTop: 'auto', paddingTop: '1.5rem', borderTop: '1px solid rgba(255,255,255,.1)' }}>
            <div onClick={() => { localStorage.removeItem('cms_token'); setAuthed(false); setToken(''); }} style={{ display: 'flex', alignItems: 'center', gap: '.75rem', padding: '.7rem .85rem', borderRadius: 8, cursor: 'pointer', color: 'rgba(255,255,255,.5)' }}>
              <span>⊗</span><span style={{ fontSize: '.875rem' }}>Sign Out</span>
            </div>
          </div>
        </div>

        {/* MAIN CONTENT */}
        <div style={{ overflowY: 'auto' }}>
          {/* Topbar */}
          <div style={{ background: '#fff', borderBottom: '1px solid #d0e8dc', padding: '1rem 2rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 100 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '.75rem' }}>
              <span style={{ fontSize: '1.1rem' }}>{SIDEBAR_ITEMS.find(i => i.id === panel)?.icon}</span>
              <span style={{ fontWeight: 700, color: '#152e22' }}>{SIDEBAR_ITEMS.find(i => i.id === panel)?.label}</span>
            </div>
            <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
              <a href="/" target="_blank" style={{ fontSize: '.82rem', color: '#005C3D', fontWeight: 600, textDecoration: 'none' }}>View Site ↗</a>
              <span style={{ fontSize: '.82rem', color: '#6a8a7a' }}>Admin</span>
            </div>
          </div>

          {loading ? (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '50vh' }}>
              <div style={{ textAlign: 'center' }}>
                <div style={{ width: 40, height: 40, border: '4px solid #d0e8dc', borderTopColor: '#005C3D', borderRadius: '50%', animation: 'spin 1s linear infinite', margin: '0 auto 1rem' }} />
                <p style={{ color: '#6a8a7a' }}>Loading content...</p>
              </div>
            </div>
          ) : (
            <div style={{ padding: '2.5rem' }}>

              {/* ── DASHBOARD ── */}
              {panel === 'dashboard' && (
                <div>
                  <div style={{ marginBottom: '2.5rem' }}>
                    <h2 style={{ fontFamily: 'Playfair Display,serif', fontSize: '1.75rem', marginBottom: '.35rem' }}>Welcome Back 👋</h2>
                    <p style={{ color: '#6a8a7a' }}>Manage your website content, leads, and settings from one place.</p>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: '1rem', marginBottom: '2rem' }}>
                    {[['Total Leads', leads.length, '📥', '#2563eb'], ['Services', services.length, '✦', '#005C3D'], ['Projects', portfolio.length, '⬡', '#7c3aed'], ['Blog Posts', blog.length, '✎', '#d97706']].map(([l, v, icon, color]) => (
                      <div key={l as string} style={{ background: '#fff', border: '1px solid #d0e8dc', borderRadius: 12, padding: '1.5rem', boxShadow: '0 2px 8px rgba(0,60,40,.07)' }}>
                        <div style={{ fontSize: '1.5rem', marginBottom: '.5rem' }}>{icon}</div>
                        <div style={{ fontFamily: 'Playfair Display,serif', fontSize: '2.2rem', fontWeight: 700, color: color as string, lineHeight: 1 }}>{v as number}</div>
                        <div style={{ fontSize: '.8rem', color: '#6a8a7a', marginTop: '.25rem' }}>{l}</div>
                      </div>
                    ))}
                  </div>
                  {/* Recent leads */}
                  <div style={{ background: '#fff', border: '1px solid #d0e8dc', borderRadius: 12, overflow: 'hidden' }}>
                    <div style={{ padding: '1.25rem 1.5rem', borderBottom: '1px solid #d0e8dc', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <h3 style={{ fontFamily: 'Playfair Display,serif', fontSize: '1.1rem' }}>Recent Leads</h3>
                      <button onClick={() => setPanel('leads')} style={{ fontSize: '.82rem', color: '#005C3D', fontWeight: 600, background: 'none', border: 'none', cursor: 'pointer' }}>View all →</button>
                    </div>
                    <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                      <thead><tr style={{ background: '#f8faf9' }}>{['Name','Phone','Service','Status','Date'].map(h => <th key={h} style={{ textAlign: 'left', padding: '.75rem 1rem', fontSize: '.72rem', fontWeight: 700, color: '#6a8a7a', textTransform: 'uppercase', letterSpacing: '.08em' }}>{h}</th>)}</tr></thead>
                      <tbody>{leads.slice(0, 5).map((l: any) => (
                        <tr key={l.id} style={{ borderTop: '1px solid #f0f4f0' }}>
                          <td style={{ padding: '.75rem 1rem', fontWeight: 600, fontSize: '.9rem' }}>{l.name || '—'}</td>
                          <td style={{ padding: '.75rem 1rem', fontSize: '.875rem', color: '#6a8a7a' }}>{l.phone || '—'}</td>
                          <td style={{ padding: '.75rem 1rem', fontSize: '.875rem', color: '#6a8a7a' }}>{l.service || '—'}</td>
                          <td style={{ padding: '.75rem 1rem' }}><span style={{ fontSize: '.72rem', padding: '.2rem .65rem', borderRadius: 100, fontWeight: 600, background: l.status === 'New' ? '#e0f2fe' : '#e8f5e9', color: l.status === 'New' ? '#0369a1' : '#166534' }}>{l.status}</span></td>
                          <td style={{ padding: '.75rem 1rem', fontSize: '.8rem', color: '#6a8a7a' }}>{l.created_at ? new Date(l.created_at).toLocaleDateString() : '—'}</td>
                        </tr>
                      ))}</tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* ── BRANDING ── */}
              {panel === 'branding' && (
                <div>
                  <div style={{ marginBottom: '2.5rem' }}><h2 style={{ fontFamily: 'Playfair Display,serif', fontSize: '1.75rem', marginBottom: '.35rem' }}>Logo & Branding</h2><p style={{ color: '#6a8a7a' }}>Update your company logo and brand identity elements.</p></div>
                  <div style={{ background: '#fff', border: '1px solid #d0e8dc', borderRadius: 12, padding: '2rem', maxWidth: 700 }}>
                    <ImageUpload currentUrl={branding.logo_url} onUpload={url => setSettings(s => ({ ...s, branding: { ...s.branding, logo_url: url } }))} folder="branding" label="Company Logo" />
                    <Field label="Company Name (shown in nav)" value={branding.company_name || ''} onChange={v => setSettings(s => ({ ...s, branding: { ...s.branding, company_name: v } }))} />
                    <Field label="Tagline (shown below name)" value={branding.tagline || ''} onChange={v => setSettings(s => ({ ...s, branding: { ...s.branding, tagline: v } }))} />
                    <button onClick={() => saveSettings('branding', settings.branding)} style={{ padding: '.85rem 2rem', background: 'linear-gradient(135deg,#C89A1C,#a07810)', color: '#fff', border: 'none', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.92rem', fontWeight: 700, cursor: 'pointer' }}>Save Branding</button>
                  </div>
                </div>
              )}

              {/* ── HERO ── */}
              {panel === 'hero' && (
                <div>
                  <div style={{ marginBottom: '2.5rem' }}><h2 style={{ fontFamily: 'Playfair Display,serif', fontSize: '1.75rem', marginBottom: '.35rem' }}>Hero Section</h2><p style={{ color: '#6a8a7a' }}>Edit the main hero section on your homepage.</p></div>
                  <div style={{ background: '#fff', border: '1px solid #d0e8dc', borderRadius: 12, padding: '2rem', maxWidth: 700 }}>
                    <ImageUpload currentUrl={heroData.bg_image_url} onUpload={url => setHeroData((h: any) => ({ ...h, bg_image_url: url }))} folder="hero" label="Background Image" />
                    <Field label="Badge Text" value={heroData.badge_text || ''} onChange={v => setHeroData((h: any) => ({ ...h, badge_text: v }))} />
                    <Field label="Heading Line 1" value={heroData.heading_line1 || ''} onChange={v => setHeroData((h: any) => ({ ...h, heading_line1: v }))} />
                    <Field label="Heading Line 2" value={heroData.heading_line2 || ''} onChange={v => setHeroData((h: any) => ({ ...h, heading_line2: v }))} />
                    <Field label="Heading Emphasis (italic gold)" value={heroData.heading_emphasis || ''} onChange={v => setHeroData((h: any) => ({ ...h, heading_emphasis: v }))} />
                    <Field label="Subtext" type="textarea" rows={3} value={heroData.subtext || ''} onChange={v => setHeroData((h: any) => ({ ...h, subtext: v }))} />
                    <Field label="CTA Button 1 Text" value={heroData.cta_primary_text || ''} onChange={v => setHeroData((h: any) => ({ ...h, cta_primary_text: v }))} />
                    <Field label="CTA Button 2 Text" value={heroData.cta_secondary_text || ''} onChange={v => setHeroData((h: any) => ({ ...h, cta_secondary_text: v }))} />
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                      {[['stat1_value','Stat 1 Value'], ['stat1_label','Stat 1 Label'], ['stat2_value','Stat 2 Value'], ['stat2_label','Stat 2 Label'], ['stat3_value','Stat 3 Value'], ['stat3_label','Stat 3 Label'], ['stat4_value','Stat 4 Value'], ['stat4_label','Stat 4 Label']].map(([key, label]) => (
                        <Field key={key} label={label} value={heroData[key] || ''} onChange={v => setHeroData((h: any) => ({ ...h, [key]: v }))} />
                      ))}
                    </div>
                    <button onClick={() => save('hero_section', { ...heroData, id: heroData.id })} style={{ padding: '.85rem 2rem', background: 'linear-gradient(135deg,#C89A1C,#a07810)', color: '#fff', border: 'none', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.92rem', fontWeight: 700, cursor: 'pointer' }}>Save Hero Section</button>
                  </div>
                </div>
              )}

              {/* ── ABOUT ── */}
              {panel === 'about' && (
                <div>
                  <div style={{ marginBottom: '2.5rem' }}><h2 style={{ fontFamily: 'Playfair Display,serif', fontSize: '1.75rem', marginBottom: '.35rem' }}>About Page</h2><p style={{ color: '#6a8a7a' }}>Edit the about page content including story, vision, and mission.</p></div>
                  <div style={{ background: '#fff', border: '1px solid #d0e8dc', borderRadius: 12, padding: '2rem', maxWidth: 700 }}>
                    <ImageUpload currentUrl={aboutData.about_image_url} onUpload={url => setAboutData((a: any) => ({ ...a, about_image_url: url }))} folder="about" label="About Image" />
                    <Field label="Years Experience Badge (e.g. 10+)" value={aboutData.years_experience || ''} onChange={v => setAboutData((a: any) => ({ ...a, years_experience: v }))} />
                    <Field label="Story Heading" value={aboutData.story_heading || ''} onChange={v => setAboutData((a: any) => ({ ...a, story_heading: v }))} />
                    <Field label="Story Body 1" type="textarea" rows={3} value={aboutData.story_body1 || ''} onChange={v => setAboutData((a: any) => ({ ...a, story_body1: v }))} />
                    <Field label="Story Body 2" type="textarea" rows={3} value={aboutData.story_body2 || ''} onChange={v => setAboutData((a: any) => ({ ...a, story_body2: v }))} />
                    <Field label="Featured Quote" type="textarea" rows={2} value={aboutData.story_quote || ''} onChange={v => setAboutData((a: any) => ({ ...a, story_quote: v }))} />
                    <Field label="Vision Statement" type="textarea" rows={3} value={aboutData.vision_text || ''} onChange={v => setAboutData((a: any) => ({ ...a, vision_text: v }))} />
                    <Field label="Mission Statement" type="textarea" rows={3} value={aboutData.mission_text || ''} onChange={v => setAboutData((a: any) => ({ ...a, mission_text: v }))} />
                    <button onClick={() => save('about_section', { ...aboutData, id: aboutData.id })} style={{ padding: '.85rem 2rem', background: 'linear-gradient(135deg,#C89A1C,#a07810)', color: '#fff', border: 'none', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.92rem', fontWeight: 700, cursor: 'pointer' }}>Save About Page</button>
                  </div>
                </div>
              )}

              {/* ── SERVICES ── */}
              {panel === 'services' && (
                <div>
                  <div style={{ marginBottom: '2.5rem', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <div><h2 style={{ fontFamily: 'Playfair Display,serif', fontSize: '1.75rem', marginBottom: '.35rem' }}>Services</h2><p style={{ color: '#6a8a7a' }}>Manage your service offerings shown on the website.</p></div>
                    <button onClick={async () => { const r = await api!.create('services', { title: 'New Service', description: 'Description', sort_order: services.length + 1 }); setServices(s => [...s, r]); }} style={{ padding: '.65rem 1.25rem', background: '#005C3D', color: '#fff', border: 'none', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.875rem', fontWeight: 600, cursor: 'pointer' }}>+ Add Service</button>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    {services.map((s: any) => (
                      <div key={s.id} style={{ background: '#fff', border: '1px solid #d0e8dc', borderRadius: 12, padding: '1.75rem' }}>
                        <div style={{ display: 'flex', gap: '1rem', alignItems: 'flex-start', marginBottom: '1rem' }}>
                          {s.image_url && <img src={s.image_url} alt={s.title} style={{ width: 80, height: 60, borderRadius: 8, objectFit: 'cover', flexShrink: 0 }} />}
                          <div style={{ flex: 1 }}>
                            <Field label="Title" value={s.title || ''} onChange={v => setServices(sv => sv.map(x => x.id === s.id ? { ...x, title: v } : x))} />
                            <Field label="Description" type="textarea" rows={2} value={s.description || ''} onChange={v => setServices(sv => sv.map(x => x.id === s.id ? { ...x, description: v } : x))} />
                          </div>
                        </div>
                        <ImageUpload currentUrl={s.image_url} onUpload={url => setServices(sv => sv.map(x => x.id === s.id ? { ...x, image_url: url } : x))} folder="services" label="Service Image" />
                        <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
                          <button onClick={() => save('services', s)} style={{ padding: '.65rem 1.25rem', background: '#005C3D', color: '#fff', border: 'none', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.875rem', fontWeight: 600, cursor: 'pointer' }}>Save</button>
                          <button onClick={async () => { await api!.del('services', s.id); setServices(sv => sv.filter(x => x.id !== s.id)); showToast('Deleted.'); }} style={{ padding: '.65rem 1.25rem', background: '#fee2e2', color: '#dc2626', border: 'none', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.875rem', fontWeight: 600, cursor: 'pointer' }}>Delete</button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* ── PORTFOLIO ── */}
              {panel === 'portfolio' && (
                <div>
                  <div style={{ marginBottom: '2.5rem', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <div><h2 style={{ fontFamily: 'Playfair Display,serif', fontSize: '1.75rem', marginBottom: '.35rem' }}>Portfolio Projects</h2><p style={{ color: '#6a8a7a' }}>Manage your project showcase.</p></div>
                    <button onClick={async () => { const r = await api!.create('portfolio_projects', { title: 'New Project', category: 'Construction', status: 'Completed', sort_order: portfolio.length + 1 }); setPortfolio(p => [...p, r]); }} style={{ padding: '.65rem 1.25rem', background: '#005C3D', color: '#fff', border: 'none', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.875rem', fontWeight: 600, cursor: 'pointer' }}>+ Add Project</button>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(340px,1fr))', gap: '1rem' }}>
                    {portfolio.map((p: any) => (
                      <div key={p.id} style={{ background: '#fff', border: '1px solid #d0e8dc', borderRadius: 12, overflow: 'hidden' }}>
                        {p.image_url && <img src={p.image_url} alt={p.title} style={{ width: '100%', height: 160, objectFit: 'cover' }} />}
                        <div style={{ padding: '1.25rem' }}>
                          <Field label="Project Title" value={p.title || ''} onChange={v => setPortfolio(pl => pl.map(x => x.id === p.id ? { ...x, title: v } : x))} />
                          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                            <Field label="Category" value={p.category || ''} onChange={v => setPortfolio(pl => pl.map(x => x.id === p.id ? { ...x, category: v } : x))} />
                            <Field label="Location" value={p.location || ''} onChange={v => setPortfolio(pl => pl.map(x => x.id === p.id ? { ...x, location: v } : x))} />
                            <Field label="Year" value={p.year || ''} onChange={v => setPortfolio(pl => pl.map(x => x.id === p.id ? { ...x, year: v } : x))} />
                            <div style={{ marginBottom: '1.25rem' }}>
                              <label style={{ display: 'block', fontSize: '.82rem', fontWeight: 600, color: '#3a5546', marginBottom: '.5rem' }}>Status</label>
                              <select value={p.status || 'Completed'} onChange={e => setPortfolio(pl => pl.map(x => x.id === p.id ? { ...x, status: e.target.value } : x))} style={{ width: '100%', padding: '.7rem 1rem', border: '1px solid #d0e8dc', borderRadius: 8, background: '#fff' }}>
                                <option>Completed</option><option>Ongoing</option><option>Planned</option>
                              </select>
                            </div>
                          </div>
                          <ImageUpload currentUrl={p.image_url} onUpload={url => setPortfolio(pl => pl.map(x => x.id === p.id ? { ...x, image_url: url } : x))} folder="portfolio" label="Project Image" />
                          <div style={{ display: 'flex', gap: '.75rem', alignItems: 'center' }}>
                            <label style={{ display: 'flex', alignItems: 'center', gap: '.4rem', fontSize: '.82rem', cursor: 'pointer' }}>
                              <input type="checkbox" checked={p.is_featured} onChange={e => setPortfolio(pl => pl.map(x => x.id === p.id ? { ...x, is_featured: e.target.checked } : x))} />
                              Featured on homepage
                            </label>
                          </div>
                          <div style={{ display: 'flex', gap: '.75rem', marginTop: '1rem' }}>
                            <button onClick={() => save('portfolio_projects', p)} style={{ flex: 1, padding: '.65rem', background: '#005C3D', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 600, cursor: 'pointer', fontSize: '.875rem' }}>Save</button>
                            <button onClick={async () => { await api!.del('portfolio_projects', p.id); setPortfolio(pl => pl.filter(x => x.id !== p.id)); }} style={{ padding: '.65rem 1rem', background: '#fee2e2', color: '#dc2626', border: 'none', borderRadius: 8, fontWeight: 600, cursor: 'pointer', fontSize: '.875rem' }}>Delete</button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* ── GALLERY ── */}
              {panel === 'gallery' && (
                <div>
                  <div style={{ marginBottom: '2.5rem', display: 'flex', justifyContent: 'space-between' }}>
                    <div><h2 style={{ fontFamily: 'Playfair Display,serif', fontSize: '1.75rem', marginBottom: '.35rem' }}>Gallery</h2><p style={{ color: '#6a8a7a' }}>Upload and manage gallery images.</p></div>
                    <button onClick={async () => { const r = await api!.create('gallery_images', { image_url: '', sort_order: gallery.length + 1 }); setGallery(g => [...g, r]); }} style={{ padding: '.65rem 1.25rem', background: '#005C3D', color: '#fff', border: 'none', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.875rem', fontWeight: 600, cursor: 'pointer' }}>+ Add Image</button>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(200px,1fr))', gap: '1rem' }}>
                    {gallery.map((img: any) => (
                      <div key={img.id} style={{ background: '#fff', border: '1px solid #d0e8dc', borderRadius: 12, overflow: 'hidden' }}>
                        <div style={{ height: 140, background: '#f0f4f0', position: 'relative' }}>
                          {img.image_url ? <img src={img.image_url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', color: '#6a8a7a' }}>No image</div>}
                        </div>
                        <div style={{ padding: '1rem' }}>
                          <ImageUpload currentUrl={img.image_url} onUpload={url => setGallery(gv => gv.map(x => x.id === img.id ? { ...x, image_url: url } : x))} folder="gallery" label="Image" />
                          <Field label="Caption (optional)" value={img.caption || ''} onChange={v => setGallery(gv => gv.map(x => x.id === img.id ? { ...x, caption: v } : x))} />
                          <div style={{ display: 'flex', gap: '.5rem' }}>
                            <button onClick={() => save('gallery_images', img)} style={{ flex: 1, padding: '.5rem', background: '#005C3D', color: '#fff', border: 'none', borderRadius: 6, fontWeight: 600, cursor: 'pointer', fontSize: '.8rem' }}>Save</button>
                            <button onClick={async () => { await api!.del('gallery_images', img.id); setGallery(gv => gv.filter(x => x.id !== img.id)); }} style={{ padding: '.5rem .75rem', background: '#fee2e2', color: '#dc2626', border: 'none', borderRadius: 6, fontWeight: 600, cursor: 'pointer', fontSize: '.8rem' }}>✕</button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* ── TEAM ── */}
              {panel === 'team' && (
                <div>
                  <div style={{ marginBottom: '2.5rem', display: 'flex', justifyContent: 'space-between' }}>
                    <div><h2 style={{ fontFamily: 'Playfair Display,serif', fontSize: '1.75rem', marginBottom: '.35rem' }}>Team Members</h2></div>
                    <button onClick={async () => { const r = await api!.create('team_members', { name: 'New Member', role: 'Role', sort_order: team.length + 1 }); setTeam(t => [...t, r]); }} style={{ padding: '.65rem 1.25rem', background: '#005C3D', color: '#fff', border: 'none', borderRadius: 8, fontSize: '.875rem', fontWeight: 600, cursor: 'pointer' }}>+ Add Member</button>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(280px,1fr))', gap: '1rem' }}>
                    {team.map((m: any) => (
                      <div key={m.id} style={{ background: '#fff', border: '1px solid #d0e8dc', borderRadius: 12, padding: '1.5rem' }}>
                        <ImageUpload currentUrl={m.image_url} onUpload={url => setTeam(tv => tv.map(x => x.id === m.id ? { ...x, image_url: url } : x))} folder="team" label="Photo" />
                        <Field label="Full Name" value={m.name || ''} onChange={v => setTeam(tv => tv.map(x => x.id === m.id ? { ...x, name: v } : x))} />
                        <Field label="Role / Title" value={m.role || ''} onChange={v => setTeam(tv => tv.map(x => x.id === m.id ? { ...x, role: v } : x))} />
                        <Field label="LinkedIn URL" value={m.linkedin_url || ''} onChange={v => setTeam(tv => tv.map(x => x.id === m.id ? { ...x, linkedin_url: v } : x))} />
                        <Field label="Instagram URL" value={m.instagram_url || ''} onChange={v => setTeam(tv => tv.map(x => x.id === m.id ? { ...x, instagram_url: v } : x))} />
                        <div style={{ display: 'flex', gap: '.75rem' }}>
                          <button onClick={() => save('team_members', m)} style={{ flex: 1, padding: '.65rem', background: '#005C3D', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 600, cursor: 'pointer', fontSize: '.875rem' }}>Save</button>
                          <button onClick={async () => { await api!.del('team_members', m.id); setTeam(tv => tv.filter(x => x.id !== m.id)); }} style={{ padding: '.65rem 1rem', background: '#fee2e2', color: '#dc2626', border: 'none', borderRadius: 8, fontWeight: 600, cursor: 'pointer', fontSize: '.875rem' }}>Delete</button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* ── TESTIMONIALS ── */}
              {panel === 'testimonials' && (
                <div>
                  <div style={{ marginBottom: '2.5rem', display: 'flex', justifyContent: 'space-between' }}>
                    <div><h2 style={{ fontFamily: 'Playfair Display,serif', fontSize: '1.75rem', marginBottom: '.35rem' }}>Testimonials</h2></div>
                    <button onClick={async () => { const r = await api!.create('testimonials', { author_name: 'Client Name', author_role: 'Role', content: 'Testimonial text', rating: 5, sort_order: testimonials.length + 1 }); setTestimonials(t => [...t, r]); }} style={{ padding: '.65rem 1.25rem', background: '#005C3D', color: '#fff', border: 'none', borderRadius: 8, fontSize: '.875rem', fontWeight: 600, cursor: 'pointer' }}>+ Add Testimonial</button>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    {testimonials.map((t: any) => (
                      <div key={t.id} style={{ background: '#fff', border: '1px solid #d0e8dc', borderRadius: 12, padding: '1.5rem' }}>
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                          <Field label="Author Name" value={t.author_name || ''} onChange={v => setTestimonials(tv => tv.map(x => x.id === t.id ? { ...x, author_name: v } : x))} />
                          <Field label="Author Role" value={t.author_role || ''} onChange={v => setTestimonials(tv => tv.map(x => x.id === t.id ? { ...x, author_role: v } : x))} />
                        </div>
                        <Field label="Testimonial Content" type="textarea" rows={3} value={t.content || ''} onChange={v => setTestimonials(tv => tv.map(x => x.id === t.id ? { ...x, content: v } : x))} />
                        <ImageUpload currentUrl={t.author_image_url} onUpload={url => setTestimonials(tv => tv.map(x => x.id === t.id ? { ...x, author_image_url: url } : x))} folder="testimonials" label="Author Photo" />
                        <div style={{ display: 'flex', gap: '.75rem' }}>
                          <button onClick={() => save('testimonials', t)} style={{ flex: 1, padding: '.65rem', background: '#005C3D', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 600, cursor: 'pointer' }}>Save</button>
                          <button onClick={async () => { await api!.del('testimonials', t.id); setTestimonials(tv => tv.filter(x => x.id !== t.id)); }} style={{ padding: '.65rem 1rem', background: '#fee2e2', color: '#dc2626', border: 'none', borderRadius: 8, fontWeight: 600, cursor: 'pointer' }}>Delete</button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* ── BLOG ── */}
              {panel === 'blog' && (
                <div>
                  <div style={{ marginBottom: '2.5rem', display: 'flex', justifyContent: 'space-between' }}>
                    <div><h2 style={{ fontFamily: 'Playfair Display,serif', fontSize: '1.75rem', marginBottom: '.35rem' }}>Blog Posts</h2></div>
                    <button onClick={async () => { const slug = `post-${Date.now()}`; const r = await api!.create('blog_posts', { title: 'New Post', slug, excerpt: 'Post excerpt', category: 'Industry Insights', author: 'Editorial Team', is_published: false, read_time: '5 min read' }); setBlog(b => [...b, r]); }} style={{ padding: '.65rem 1.25rem', background: '#005C3D', color: '#fff', border: 'none', borderRadius: 8, fontSize: '.875rem', fontWeight: 600, cursor: 'pointer' }}>+ New Post</button>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    {blog.map((p: any) => (
                      <div key={p.id} style={{ background: '#fff', border: '1px solid #d0e8dc', borderRadius: 12, padding: '1.5rem' }}>
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                          <Field label="Title" value={p.title || ''} onChange={v => setBlog(bv => bv.map(x => x.id === p.id ? { ...x, title: v } : x))} />
                          <Field label="Category" value={p.category || ''} onChange={v => setBlog(bv => bv.map(x => x.id === p.id ? { ...x, category: v } : x))} />
                          <Field label="Author" value={p.author || ''} onChange={v => setBlog(bv => bv.map(x => x.id === p.id ? { ...x, author: v } : x))} />
                          <Field label="Read Time (e.g. 5 min read)" value={p.read_time || ''} onChange={v => setBlog(bv => bv.map(x => x.id === p.id ? { ...x, read_time: v } : x))} />
                        </div>
                        <Field label="Excerpt / Summary" type="textarea" rows={2} value={p.excerpt || ''} onChange={v => setBlog(bv => bv.map(x => x.id === p.id ? { ...x, excerpt: v } : x))} />
                        <Field label="Full Content (markdown supported)" type="textarea" rows={6} value={p.content || ''} onChange={v => setBlog(bv => bv.map(x => x.id === p.id ? { ...x, content: v } : x))} />
                        <ImageUpload currentUrl={p.cover_image_url} onUpload={url => setBlog(bv => bv.map(x => x.id === p.id ? { ...x, cover_image_url: url } : x))} folder="blog" label="Cover Image" />
                        <div style={{ display: 'flex', gap: '.75rem', alignItems: 'center', marginBottom: '1rem' }}>
                          <label style={{ display: 'flex', alignItems: 'center', gap: '.4rem', fontSize: '.82rem', cursor: 'pointer' }}>
                            <input type="checkbox" checked={p.is_published} onChange={e => setBlog(bv => bv.map(x => x.id === p.id ? { ...x, is_published: e.target.checked } : x))} />
                            Published (visible on website)
                          </label>
                        </div>
                        <div style={{ display: 'flex', gap: '.75rem' }}>
                          <button onClick={() => save('blog_posts', p)} style={{ flex: 1, padding: '.65rem', background: '#005C3D', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 600, cursor: 'pointer' }}>Save</button>
                          <button onClick={async () => { await api!.del('blog_posts', p.id); setBlog(bv => bv.filter(x => x.id !== p.id)); }} style={{ padding: '.65rem 1rem', background: '#fee2e2', color: '#dc2626', border: 'none', borderRadius: 8, fontWeight: 600, cursor: 'pointer' }}>Delete</button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* ── FAQ ── */}
              {panel === 'faq' && (
                <div>
                  <div style={{ marginBottom: '2.5rem', display: 'flex', justifyContent: 'space-between' }}>
                    <div><h2 style={{ fontFamily: 'Playfair Display,serif', fontSize: '1.75rem', marginBottom: '.35rem' }}>FAQ</h2></div>
                    <button onClick={async () => { const r = await api!.create('faq_items', { question: 'New Question?', answer: 'Answer here.', sort_order: faqs.length + 1 }); setFaqs(f => [...f, r]); }} style={{ padding: '.65rem 1.25rem', background: '#005C3D', color: '#fff', border: 'none', borderRadius: 8, fontSize: '.875rem', fontWeight: 600, cursor: 'pointer' }}>+ Add FAQ</button>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    {faqs.map((f: any) => (
                      <div key={f.id} style={{ background: '#fff', border: '1px solid #d0e8dc', borderRadius: 12, padding: '1.5rem' }}>
                        <Field label="Question" value={f.question || ''} onChange={v => setFaqs(fv => fv.map(x => x.id === f.id ? { ...x, question: v } : x))} />
                        <Field label="Answer" type="textarea" rows={3} value={f.answer || ''} onChange={v => setFaqs(fv => fv.map(x => x.id === f.id ? { ...x, answer: v } : x))} />
                        <div style={{ display: 'flex', gap: '.75rem' }}>
                          <button onClick={() => save('faq_items', f)} style={{ flex: 1, padding: '.65rem', background: '#005C3D', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 600, cursor: 'pointer' }}>Save</button>
                          <button onClick={async () => { await api!.del('faq_items', f.id); setFaqs(fv => fv.filter(x => x.id !== f.id)); }} style={{ padding: '.65rem 1rem', background: '#fee2e2', color: '#dc2626', border: 'none', borderRadius: 8, fontWeight: 600, cursor: 'pointer' }}>Delete</button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* ── SOCIAL MEDIA ── */}
              {panel === 'social' && (
                <div>
                  <div style={{ marginBottom: '2.5rem' }}><h2 style={{ fontFamily: 'Playfair Display,serif', fontSize: '1.75rem', marginBottom: '.35rem' }}>Social Media Links</h2><p style={{ color: '#6a8a7a' }}>Add your social handles — these appear in the footer and contact page.</p></div>
                  <div style={{ background: '#fff', border: '1px solid #d0e8dc', borderRadius: 12, padding: '2rem', maxWidth: 600 }}>
                    {[['instagram','Instagram', '📸'], ['facebook','Facebook', '👍'], ['linkedin','LinkedIn', '💼'], ['twitter','Twitter / X', '🐦'], ['youtube','YouTube', '▶️'], ['tiktok','TikTok', '🎵']].map(([key, label, icon]) => (
                      <Field key={key} label={`${icon} ${label} URL`} value={social[key] || ''} onChange={v => setSettings(s => ({ ...s, social: { ...s.social, [key]: v } }))} placeholder={`https://${key}.com/yourprofile`} />
                    ))}
                    <button onClick={() => saveSettings('social', settings.social)} style={{ padding: '.85rem 2rem', background: 'linear-gradient(135deg,#C89A1C,#a07810)', color: '#fff', border: 'none', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.92rem', fontWeight: 700, cursor: 'pointer' }}>Save Social Links</button>
                  </div>
                </div>
              )}

              {/* ── CONTACT INFO ── */}
              {panel === 'contact' && (
                <div>
                  <div style={{ marginBottom: '2.5rem' }}><h2 style={{ fontFamily: 'Playfair Display,serif', fontSize: '1.75rem', marginBottom: '.35rem' }}>Contact Information</h2><p style={{ color: '#6a8a7a' }}>Update your contact details shown across the website.</p></div>
                  <div style={{ background: '#fff', border: '1px solid #d0e8dc', borderRadius: 12, padding: '2rem', maxWidth: 600 }}>
                    <Field label="Phone / WhatsApp Number (display)" value={contact.phone || ''} onChange={v => setSettings(s => ({ ...s, contact: { ...s.contact, phone: v } }))} placeholder="+234 706 502 4741" />
                    <Field label="WhatsApp Number (digits only, for links)" value={contact.whatsapp || ''} onChange={v => setSettings(s => ({ ...s, contact: { ...s.contact, whatsapp: v } }))} placeholder="2347065024741" />
                    <Field label="Email Address" value={contact.email || ''} onChange={v => setSettings(s => ({ ...s, contact: { ...s.contact, email: v } }))} />
                    <Field label="Office Address" type="textarea" rows={2} value={contact.address || ''} onChange={v => setSettings(s => ({ ...s, contact: { ...s.contact, address: v } }))} />
                    <Field label="Business Hours" value={contact.business_hours || ''} onChange={v => setSettings(s => ({ ...s, contact: { ...s.contact, business_hours: v } }))} placeholder="Mon-Fri: 9:00 AM – 6:00 PM (WAT)" />
                    <button onClick={() => saveSettings('contact', settings.contact)} style={{ padding: '.85rem 2rem', background: 'linear-gradient(135deg,#C89A1C,#a07810)', color: '#fff', border: 'none', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.92rem', fontWeight: 700, cursor: 'pointer' }}>Save Contact Info</button>
                  </div>
                </div>
              )}

              {/* ── LEADS / CRM ── */}
              {panel === 'leads' && (
                <div>
                  <div style={{ marginBottom: '2.5rem' }}><h2 style={{ fontFamily: 'Playfair Display,serif', fontSize: '1.75rem', marginBottom: '.35rem' }}>Leads & CRM</h2><p style={{ color: '#6a8a7a' }}>All contact form submissions, synced with Airtable and WhatsApp notifications via n8n.</p></div>
                  <div style={{ background: '#fff', border: '1px solid #d0e8dc', borderRadius: 12, overflow: 'hidden' }}>
                    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '.875rem' }}>
                      <thead><tr style={{ background: '#f8faf9' }}>{['Name','Email','Phone','Service','Budget','Status','Airtable','Date'].map(h => <th key={h} style={{ textAlign: 'left', padding: '.85rem 1rem', fontSize: '.72rem', fontWeight: 700, color: '#6a8a7a', textTransform: 'uppercase', letterSpacing: '.08em', borderBottom: '1px solid #d0e8dc' }}>{h}</th>)}</tr></thead>
                      <tbody>{leads.map((l: any) => (
                        <tr key={l.id} style={{ borderBottom: '1px solid #f0f4f0' }}>
                          <td style={{ padding: '.85rem 1rem', fontWeight: 600 }}>{l.name || '—'}</td>
                          <td style={{ padding: '.85rem 1rem', color: '#6a8a7a' }}>{l.email || '—'}</td>
                          <td style={{ padding: '.85rem 1rem', color: '#6a8a7a' }}>{l.phone || '—'}</td>
                          <td style={{ padding: '.85rem 1rem', color: '#6a8a7a' }}>{l.service || '—'}</td>
                          <td style={{ padding: '.85rem 1rem', color: '#6a8a7a' }}>{l.budget || '—'}</td>
                          <td style={{ padding: '.85rem 1rem' }}><span style={{ fontSize: '.72rem', padding: '.2rem .65rem', borderRadius: 100, fontWeight: 600, background: l.status === 'New' ? '#e0f2fe' : '#e8f5e9', color: l.status === 'New' ? '#0369a1' : '#166534' }}>{l.status || 'New'}</span></td>
                          <td style={{ padding: '.85rem 1rem', color: '#6a8a7a' }}>{l.airtable_id ? <span style={{ color: '#005C3D', fontSize: '.72rem' }}>✓ Synced</span> : <span style={{ color: '#d97706', fontSize: '.72rem' }}>Pending</span>}</td>
                          <td style={{ padding: '.85rem 1rem', color: '#6a8a7a', fontSize: '.8rem' }}>{l.created_at ? new Date(l.created_at).toLocaleDateString('en-GB') : '—'}</td>
                        </tr>
                      ))}</tbody>
                    </table>
                    {leads.length === 0 && <div style={{ textAlign: 'center', padding: '3rem', color: '#6a8a7a' }}>No leads yet. They will appear here when visitors submit the contact form.</div>}
                  </div>
                </div>
              )}

              {/* ── AUTOMATION SETTINGS ── */}
              {panel === 'settings' && (
                <div>
                  <div style={{ marginBottom: '2.5rem' }}><h2 style={{ fontFamily: 'Playfair Display,serif', fontSize: '1.75rem', marginBottom: '.35rem' }}>Automation Settings</h2><p style={{ color: '#6a8a7a' }}>Configure n8n webhooks for WhatsApp notifications and lead automation.</p></div>
                  <div style={{ background: '#fff', border: '1px solid #d0e8dc', borderRadius: 12, padding: '2rem', maxWidth: 600 }}>
                    <Field label="n8n Contact Form Webhook URL" value={automation.n8n_webhook_url || ''} onChange={v => setSettings(s => ({ ...s, automation: { ...s.automation, n8n_webhook_url: v } }))} placeholder="https://flow.jillglobalservices.com/webhook/..." />
                    <Field label="WhatsApp Notification Number (leads to notify)" value={automation.whatsapp_notification_number || ''} onChange={v => setSettings(s => ({ ...s, automation: { ...s.automation, whatsapp_notification_number: v } }))} placeholder="2347065024741" />
                    <Field label="Admin Notification Email" value={automation.admin_email || ''} onChange={v => setSettings(s => ({ ...s, automation: { ...s.automation, admin_email: v } }))} />
                    <div style={{ background: '#f0f4f0', borderRadius: 8, padding: '1.25rem', marginBottom: '1.25rem' }}>
                      <div style={{ fontSize: '.8rem', fontWeight: 700, color: '#3a5546', marginBottom: '.5rem' }}>🔗 How Automation Works</div>
                      <ul style={{ fontSize: '.8rem', color: '#6a8a7a', lineHeight: 1.8, paddingLeft: '1.25rem' }}>
                        <li>Contact form submission → saved to Supabase</li>
                        <li>Lead synced to Airtable CRM automatically</li>
                        <li>n8n webhook triggered with lead data</li>
                        <li>WhatsApp notification sent via your n8n flow</li>
                      </ul>
                    </div>
                    <button onClick={() => saveSettings('automation', settings.automation)} style={{ padding: '.85rem 2rem', background: 'linear-gradient(135deg,#C89A1C,#a07810)', color: '#fff', border: 'none', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.92rem', fontWeight: 700, cursor: 'pointer' }}>Save Automation Settings</button>
                  </div>
                </div>
              )}

              {/* ── JOBS ── */}
              {panel === 'jobs' && (
                <div>
                  <div style={{ marginBottom: '2.5rem', display: 'flex', justifyContent: 'space-between' }}>
                    <div><h2 style={{ fontFamily: 'Playfair Display,serif', fontSize: '1.75rem', marginBottom: '.35rem' }}>Job Openings</h2></div>
                    <button onClick={async () => { const r = await api!.create('job_openings', { title: 'New Role', department: 'Engineering', location: 'Lagos', job_type: 'Full-time', sort_order: jobs.length + 1 }); setJobs(j => [...j, r]); }} style={{ padding: '.65rem 1.25rem', background: '#005C3D', color: '#fff', border: 'none', borderRadius: 8, fontSize: '.875rem', fontWeight: 600, cursor: 'pointer' }}>+ Add Job</button>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    {jobs.map((j: any) => (
                      <div key={j.id} style={{ background: '#fff', border: '1px solid #d0e8dc', borderRadius: 12, padding: '1.5rem' }}>
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                          <Field label="Job Title" value={j.title || ''} onChange={v => setJobs(jv => jv.map(x => x.id === j.id ? { ...x, title: v } : x))} />
                          <Field label="Department" value={j.department || ''} onChange={v => setJobs(jv => jv.map(x => x.id === j.id ? { ...x, department: v } : x))} />
                          <Field label="Location" value={j.location || ''} onChange={v => setJobs(jv => jv.map(x => x.id === j.id ? { ...x, location: v } : x))} />
                          <Field label="Job Type" value={j.job_type || ''} onChange={v => setJobs(jv => jv.map(x => x.id === j.id ? { ...x, job_type: v } : x))} />
                        </div>
                        <Field label="Job Description" type="textarea" rows={3} value={j.description || ''} onChange={v => setJobs(jv => jv.map(x => x.id === j.id ? { ...x, description: v } : x))} />
                        <div style={{ display: 'flex', gap: '.75rem' }}>
                          <button onClick={() => save('job_openings', j)} style={{ flex: 1, padding: '.65rem', background: '#005C3D', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 600, cursor: 'pointer' }}>Save</button>
                          <button onClick={async () => { await api!.del('job_openings', j.id); setJobs(jv => jv.filter(x => x.id !== j.id)); }} style={{ padding: '.65rem 1rem', background: '#fee2e2', color: '#dc2626', border: 'none', borderRadius: 8, fontWeight: 600, cursor: 'pointer' }}>Delete</button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

            </div>
          )}
        </div>
      </div>

      {/* Toast */}
      {toast && (
        <div style={{ position: 'fixed', bottom: '2rem', left: '50%', transform: 'translateX(-50%)', background: '#003d28', color: '#fff', padding: '.85rem 2rem', borderRadius: 100, fontSize: '.875rem', fontWeight: 600, zIndex: 9999, boxShadow: '0 8px 24px rgba(0,0,0,.3)' }}>{toast}</div>
      )}

      <style>{`
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: Outfit, sans-serif; }
      `}</style>
    </>
  );
}
