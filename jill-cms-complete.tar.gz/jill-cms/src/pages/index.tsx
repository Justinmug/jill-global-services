import { useState, useEffect, useRef } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import type { GetStaticProps } from 'next';
import {
  getHeroSection, getServices, getPortfolio, getTestimonials,
  getTeam, getBlogPosts, getFaqs, getGallery, getJobs,
  getSiteSettings, getAboutSection
} from '@/lib/supabase';

// ─── Types ─────────────────────────────────────────────────
interface SiteData {
  settings: Record<string, any>;
  hero: any;
  about: any;
  services: any[];
  portfolio: any[];
  gallery: any[];
  team: any[];
  testimonials: any[];
  blog: any[];
  faqs: any[];
  jobs: any[];
}

// ─── Nav ────────────────────────────────────────────────────
function Nav({ settings, currentPage, onNav }: { settings: any; currentPage: string; onNav: (p: string) => void }) {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const contact = settings?.contact || {};
  const social = settings?.social || {};
  const branding = settings?.branding || {};

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 80);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const navLinks = ['home','about','services','portfolio','gallery','blog','faq','careers','contact'];

  return (
    <nav style={{
      position: 'fixed', top: 0, left: 0, right: 0, zIndex: 500, padding: '0 2.5rem',
      height: scrolled ? '64px' : '74px', display: 'flex', alignItems: 'center',
      justifyContent: 'space-between', background: scrolled ? 'rgba(0,44,28,.99)' : 'rgba(0,61,40,.97)',
      backdropFilter: 'blur(14px)', borderBottom: '1px solid rgba(255,255,255,.06)',
      transition: 'all .35s', boxShadow: scrolled ? '0 4px 28px rgba(0,0,0,.3)' : 'none'
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '.75rem', cursor: 'pointer' }} onClick={() => onNav('home')}>
        {branding.logo_url ? (
          <img src={branding.logo_url} alt="Logo" style={{ width: 42, height: 42, borderRadius: 10, objectFit: 'cover' }} />
        ) : (
          <div style={{ width: 42, height: 42, background: 'linear-gradient(135deg,#C89A1C,#a07810)', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Playfair Display,serif', fontWeight: 700, color: '#fff', fontSize: '1.1rem', boxShadow: '0 4px 14px rgba(200,154,28,.4)' }}>JG</div>
        )}
        <div>
          <div style={{ fontFamily: 'Playfair Display,serif', fontWeight: 600, color: '#fff', lineHeight: 1.2 }}>{branding.company_name || 'Jill Global Services'}</div>
          <div style={{ fontFamily: 'Outfit,sans-serif', fontSize: '.6rem', fontWeight: 400, letterSpacing: '.18em', textTransform: 'uppercase', color: 'rgba(255,255,255,.5)' }}>{branding.tagline || 'Building Landmark Projects'}</div>
        </div>
      </div>

      {/* Desktop nav */}
      <ul style={{ display: open ? 'none' : 'flex', alignItems: 'center', gap: '.15rem', listStyle: 'none', '@media(max-width:768px)': { display: 'none' } } as any}>
        {navLinks.map(link => (
          <li key={link}>
            <a onClick={() => onNav(link)} style={{
              padding: '.45rem .85rem', fontSize: '.83rem', fontWeight: 500, cursor: 'pointer',
              color: currentPage === link ? '#fff' : 'rgba(255,255,255,.75)',
              background: currentPage === link ? 'rgba(255,255,255,.1)' : 'transparent',
              borderRadius: 7, transition: 'all .2s', textTransform: 'capitalize',
              ...(link === 'contact' ? { background: '#C89A1C', color: '#fff', padding: '.5rem 1.2rem', fontWeight: 600, boxShadow: '0 3px 12px rgba(200,154,28,.4)' } : {})
            }}>
              {link === 'faq' ? 'FAQ' : link.charAt(0).toUpperCase() + link.slice(1)}
            </a>
          </li>
        ))}
      </ul>

      {/* Mobile hamburger */}
      <button onClick={() => setOpen(!open)} style={{ display: 'none', background: 'none', border: 'none', cursor: 'pointer', padding: '.5rem' }}
        className="hamburger-btn">
        <span style={{ display: 'block', width: 22, height: 2, background: '#fff', borderRadius: 2, margin: '5px 0', transition: 'all .3s', transform: open ? 'translateY(7px) rotate(45deg)' : 'none' }} />
        <span style={{ display: 'block', width: 22, height: 2, background: '#fff', borderRadius: 2, margin: '5px 0', opacity: open ? 0 : 1, transition: 'all .3s' }} />
        <span style={{ display: 'block', width: 22, height: 2, background: '#fff', borderRadius: 2, margin: '5px 0', transition: 'all .3s', transform: open ? 'translateY(-7px) rotate(-45deg)' : 'none' }} />
      </button>

      {/* Mobile menu overlay */}
      {open && (
        <div style={{ position: 'fixed', inset: 0, background: 'var(--green-deep)', zIndex: 500, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '2rem' }}>
          {navLinks.map(link => (
            <a key={link} onClick={() => { onNav(link); setOpen(false); }} style={{ fontSize: '1.2rem', color: '#fff', cursor: 'pointer', textTransform: 'capitalize' }}>
              {link === 'faq' ? 'FAQ' : link.charAt(0).toUpperCase() + link.slice(1)}
            </a>
          ))}
        </div>
      )}
    </nav>
  );
}

// ─── WhatsApp Float ─────────────────────────────────────────
function WAFloat({ whatsapp }: { whatsapp: string }) {
  return (
    <a href={`https://wa.me/${whatsapp}?text=Hello%20Jill%20Global%20Services%2C%20I%20would%20like%20to%20discuss%20a%20project.`}
      target="_blank" rel="noopener noreferrer"
      style={{ position: 'fixed', bottom: '2rem', right: '2rem', zIndex: 400, width: '3.5rem', height: '3.5rem', background: '#25D366', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 6px 24px rgba(37,211,102,.45)', cursor: 'pointer', transition: 'all .3s' }}>
      <svg width="28" height="28" viewBox="0 0 24 24" fill="#fff">
        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347zM5.077 18.509l.526-1.917A9.924 9.924 0 012.1 12.009C2.1 6.528 6.528 2.1 12.009 2.1s9.909 4.428 9.909 9.909-4.428 9.909-9.909 9.909a9.924 9.924 0 01-4.804-1.228l-.128-.075-1.526.399z"/>
      </svg>
    </a>
  );
}

// ─── Section Renderer ────────────────────────────────────────
function PageRenderer({ page, data, onNav, settings }: { page: string; data: SiteData; onNav: (p: string) => void; settings: any }) {
  const contact = settings?.contact || {};
  const social = settings?.social || {};
  const branding = settings?.branding || {};
  const automation = settings?.automation || {};

  const waLink = `https://wa.me/${contact.whatsapp || '2347065024741'}?text=Hello%20Jill%20Global%20Services%2C%20I%20would%20like%20to%20discuss%20a%20project.`;

  // === HOME PAGE ===
  if (page === 'home') {
    const hero = data.hero || {};
    const [nlEmail, setNlEmail] = useState('');
    const [nlDone, setNlDone] = useState(false);

    const subscribeNewsletter = async () => {
      if (!nlEmail) return;
      await fetch('/api/newsletter', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: nlEmail }) });
      setNlDone(true);
    };

    return (
      <>
        {/* HERO */}
        <section style={{ minHeight: '100vh', position: 'relative', display: 'flex', alignItems: 'center', overflow: 'hidden' }}>
          <img src={hero.bg_image_url || 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=1600&q=85'} alt="Hero" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover' }} />
          <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(105deg,rgba(0,44,28,.94) 0%,rgba(0,44,28,.78) 55%,rgba(0,44,28,.45) 100%)' }} />
          <div style={{ position: 'relative', zIndex: 2, maxWidth: 1200, margin: '0 auto', padding: '9rem 2rem 5rem', width: '100%' }}>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: '.6rem', background: 'rgba(200,154,28,.18)', border: '1px solid rgba(200,154,28,.35)', color: '#e8b83a', padding: '.4rem 1.1rem', borderRadius: 100, fontSize: '.72rem', fontWeight: 700, letterSpacing: '.18em', textTransform: 'uppercase', marginBottom: '1.75rem' }}>
              <span style={{ width: 5, height: 5, background: '#e8b83a', borderRadius: '50%' }} />
              {hero.badge_text || 'Engineering Excellence Since 2015'}
            </div>
            <h1 style={{ fontSize: 'clamp(2.6rem,5.5vw,5rem)', fontWeight: 700, color: '#fff', maxWidth: 820, lineHeight: 1.08, marginBottom: '1.6rem' }}>
              {hero.heading_line1 || 'Building Landmark'}<br />
              {hero.heading_line2 || 'Projects. Creating'}<br />
              <em style={{ fontStyle: 'italic', color: '#e8b83a' }}>{hero.heading_emphasis || 'Timeless Spaces.'}</em>
            </h1>
            <p style={{ fontSize: '1.1rem', color: 'rgba(255,255,255,.8)', maxWidth: 560, lineHeight: 1.8, marginBottom: '2.5rem', fontWeight: 300 }}>
              {hero.subtext || 'Nigeria\'s leading integrated construction, interior design & property solutions company.'}
            </p>
            <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', marginBottom: '4rem' }}>
              <button onClick={() => onNav('contact')} style={{ display: 'inline-flex', alignItems: 'center', gap: '.55rem', padding: '.85rem 2rem', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.92rem', fontWeight: 600, cursor: 'pointer', border: 'none', background: 'linear-gradient(135deg,#C89A1C,#a07810)', color: '#fff', boxShadow: '0 4px 18px rgba(200,154,28,.35)', transition: 'all .28s' }}>
                {hero.cta_primary_text || 'Request a Consultation'} →
              </button>
              <button onClick={() => onNav('portfolio')} style={{ display: 'inline-flex', alignItems: 'center', padding: '.85rem 2rem', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.92rem', fontWeight: 600, cursor: 'pointer', background: 'transparent', color: '#fff', border: '1.5px solid rgba(255,255,255,.4)', transition: 'all .28s' }}>
                {hero.cta_secondary_text || 'View Our Projects'}
              </button>
            </div>
            <div style={{ display: 'flex', gap: '3rem', flexWrap: 'wrap' }}>
              {[
                [hero.stat1_value || '150+', hero.stat1_label || 'Projects Delivered'],
                [hero.stat2_value || '50+', hero.stat2_label || 'Happy Clients'],
                [hero.stat3_value || '10+', hero.stat3_label || 'Years Experience'],
                [hero.stat4_value || '100%', hero.stat4_label || 'Quality Commitment'],
              ].map(([val, lbl]) => (
                <div key={lbl} style={{ textAlign: 'center' }}>
                  <div style={{ fontFamily: 'Playfair Display,serif', fontSize: '2.2rem', fontWeight: 700, color: '#e8b83a', lineHeight: 1 }}>{val}</div>
                  <div style={{ fontSize: '.73rem', color: 'rgba(255,255,255,.55)', letterSpacing: '.08em', marginTop: '.3rem', textTransform: 'uppercase' }}>{lbl}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* SERVICES PREVIEW */}
        <section style={{ padding: '6rem 0', background: '#f8faf9' }}>
          <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 2rem' }}>
            <div style={{ textAlign: 'center', marginBottom: '3.5rem' }}>
              <span style={{ fontSize: '.72rem', fontWeight: 700, letterSpacing: '.22em', textTransform: 'uppercase', color: '#C89A1C', display: 'block', marginBottom: '.75rem' }}>What We Do</span>
              <h2 style={{ fontSize: 'clamp(1.9rem,3.5vw,2.9rem)', fontWeight: 600, marginBottom: '.9rem' }}>Comprehensive Solutions for Every Project</h2>
              <p style={{ color: '#6a8a7a', maxWidth: 660, margin: '0 auto' }}>From concept to completion — integrated services covering construction, design, and property development.</p>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(300px,1fr))', gap: '1.5rem' }}>
              {data.services.slice(0, 5).map((s: any) => (
                <div key={s.id} style={{ background: '#fff', border: '1px solid #d0e8dc', borderRadius: 14, overflow: 'hidden', transition: 'all .3s', cursor: 'pointer' }}
                  onMouseEnter={e => { (e.currentTarget as any).style.transform = 'translateY(-6px)'; (e.currentTarget as any).style.boxShadow = '0 12px 40px rgba(0,60,40,.14)'; }}
                  onMouseLeave={e => { (e.currentTarget as any).style.transform = ''; (e.currentTarget as any).style.boxShadow = ''; }}>
                  {s.image_url && <div style={{ height: 190, overflow: 'hidden' }}><img src={s.image_url} alt={s.title} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /></div>}
                  <div style={{ padding: '1.75rem' }}>
                    <h3 style={{ fontSize: '1.18rem', marginBottom: '.6rem' }}>{s.title}</h3>
                    <p style={{ fontSize: '.875rem', color: '#6a8a7a', lineHeight: 1.75 }}>{s.description}</p>
                    <a href={`https://wa.me/${contact.whatsapp || '2347065024741'}?text=I%20am%20interested%20in%20${encodeURIComponent(s.title)}`} target="_blank" rel="noopener noreferrer"
                      style={{ display: 'inline-flex', alignItems: 'center', gap: '.4rem', marginTop: '1.25rem', fontSize: '.8rem', fontWeight: 700, color: '#005C3D' }}>
                      Explore service →
                    </a>
                  </div>
                </div>
              ))}
              {/* CTA card */}
              <div style={{ background: 'linear-gradient(135deg,#003d28,#1a7a54)', borderRadius: 14, padding: '2.5rem', display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: '1.25rem' }}>
                <span style={{ fontSize: '.72rem', fontWeight: 700, letterSpacing: '.22em', textTransform: 'uppercase', color: '#e8b83a' }}>Start Today</span>
                <h3 style={{ color: '#fff', fontSize: '1.6rem', lineHeight: 1.2 }}>Have a project in mind?</h3>
                <p style={{ color: 'rgba(255,255,255,.7)', fontSize: '.875rem', lineHeight: 1.75 }}>Tell us your vision. We handle everything from concept to completion.</p>
                <button onClick={() => onNav('contact')} style={{ display: 'inline-flex', alignItems: 'center', gap: '.55rem', padding: '.85rem 2rem', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.92rem', fontWeight: 600, cursor: 'pointer', border: 'none', background: 'linear-gradient(135deg,#C89A1C,#a07810)', color: '#fff', width: 'fit-content' }}>
                  Get Free Estimate →
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* FEATURED PORTFOLIO */}
        <section style={{ padding: '6rem 0' }}>
          <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 2rem' }}>
            <div style={{ textAlign: 'center', marginBottom: '3.5rem' }}>
              <span style={{ fontSize: '.72rem', fontWeight: 700, letterSpacing: '.22em', textTransform: 'uppercase', color: '#C89A1C', display: 'block', marginBottom: '.75rem' }}>Our Portfolio</span>
              <h2 style={{ fontSize: 'clamp(1.9rem,3.5vw,2.9rem)', fontWeight: 600 }}>Featured Projects</h2>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(300px,1fr))', gap: '1.5rem' }}>
              {data.portfolio.filter((p: any) => p.is_featured).slice(0, 3).map((p: any) => (
                <div key={p.id} style={{ borderRadius: 14, overflow: 'hidden', cursor: 'pointer', position: 'relative', boxShadow: '0 2px 8px rgba(0,60,40,.07)', transition: 'all .35s' }}
                  onMouseEnter={e => (e.currentTarget as any).style.transform = 'translateY(-5px)'}
                  onMouseLeave={e => (e.currentTarget as any).style.transform = ''}>
                  <div style={{ aspectRatio: '4/3', overflow: 'hidden', position: 'relative' }}>
                    <img src={p.image_url} alt={p.title} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to top,rgba(0,44,28,.92),transparent 50%)' }} />
                    <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, padding: '1.5rem' }}>
                      <span style={{ display: 'inline-block', background: '#C89A1C', color: '#fff', fontSize: '.65rem', fontWeight: 700, letterSpacing: '.1em', textTransform: 'uppercase', padding: '.2rem .65rem', borderRadius: 100, marginBottom: '.5rem' }}>{p.category}</span>
                      <h3 style={{ color: '#fff', fontSize: '1.05rem', marginBottom: '.2rem' }}>{p.title}</h3>
                      <p style={{ color: 'rgba(255,255,255,.7)', fontSize: '.77rem' }}>{p.location} · {p.year}</p>
                    </div>
                  </div>
                  <div style={{ background: '#fff', padding: '1.25rem 1.5rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div><div style={{ fontSize: '.95rem', fontWeight: 700 }}>{p.title}</div><div style={{ fontSize: '.72rem', color: '#6a8a7a' }}>{p.description || p.category}</div></div>
                    <span style={{ fontSize: '.7rem', padding: '.2rem .6rem', borderRadius: 100, fontWeight: 600, background: p.status === 'Completed' ? '#e8f5e9' : '#fff3e0', color: p.status === 'Completed' ? '#2e7d32' : '#e65100' }}>{p.status}</span>
                  </div>
                </div>
              ))}
            </div>
            <div style={{ textAlign: 'center', marginTop: '2.5rem' }}>
              <button onClick={() => onNav('portfolio')} style={{ display: 'inline-flex', alignItems: 'center', gap: '.55rem', padding: '.85rem 2rem', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.92rem', fontWeight: 600, cursor: 'pointer', border: 'none', background: '#005C3D', color: '#fff' }}>
                View Full Portfolio →
              </button>
            </div>
          </div>
        </section>

        {/* TESTIMONIALS */}
        <section style={{ padding: '6rem 0', background: '#eef6f1' }}>
          <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 2rem' }}>
            <div style={{ textAlign: 'center', marginBottom: '3.5rem' }}>
              <span style={{ fontSize: '.72rem', fontWeight: 700, letterSpacing: '.22em', textTransform: 'uppercase', color: '#C89A1C', display: 'block', marginBottom: '.75rem' }}>Client Feedback</span>
              <h2 style={{ fontSize: 'clamp(1.9rem,3.5vw,2.9rem)', fontWeight: 600 }}>What Our Clients Say</h2>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(280px,1fr))', gap: '1.5rem' }}>
              {data.testimonials.map((t: any) => (
                <div key={t.id} style={{ background: '#fff', border: '1px solid #d0e8dc', borderRadius: 14, padding: '2.5rem', position: 'relative', transition: 'all .3s' }}>
                  <div style={{ position: 'absolute', top: '1.5rem', right: '1.75rem', fontFamily: 'Playfair Display,serif', fontSize: '4rem', color: '#e6f4ee', lineHeight: 1, fontWeight: 700 }}>"</div>
                  <div style={{ display: 'flex', gap: '.2rem', marginBottom: '1.25rem' }}>
                    {[...Array(t.rating || 5)].map((_, i) => <span key={i} style={{ color: '#C89A1C', fontSize: '.9rem' }}>★</span>)}
                  </div>
                  <p style={{ fontSize: '.915rem', color: '#3a5546', lineHeight: 1.8, fontStyle: 'italic', marginBottom: '1.5rem' }}>"{t.content}"</p>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '.9rem' }}>
                    {t.author_image_url && <div style={{ width: '2.75rem', height: '2.75rem', borderRadius: '50%', overflow: 'hidden', border: '2px solid #e6f4ee' }}><img src={t.author_image_url} alt={t.author_name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /></div>}
                    <div><div style={{ fontWeight: 700, fontSize: '.9rem' }}>{t.author_name}</div><div style={{ fontSize: '.75rem', color: '#6a8a7a' }}>{t.author_role}</div></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* TEAM PREVIEW */}
        <section style={{ padding: '6rem 0' }}>
          <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 2rem' }}>
            <div style={{ textAlign: 'center', marginBottom: '3.5rem' }}>
              <span style={{ fontSize: '.72rem', fontWeight: 700, letterSpacing: '.22em', textTransform: 'uppercase', color: '#C89A1C', display: 'block', marginBottom: '.75rem' }}>Our People</span>
              <h2 style={{ fontSize: 'clamp(1.9rem,3.5vw,2.9rem)', fontWeight: 600 }}>Meet the Leadership Team</h2>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(220px,1fr))', gap: '1.5rem' }}>
              {data.team.map((member: any) => (
                <div key={member.id} style={{ background: '#fff', border: '1px solid #d0e8dc', borderRadius: 14, overflow: 'hidden', textAlign: 'center', transition: 'all .3s' }}>
                  <div style={{ height: 220, overflow: 'hidden', position: 'relative' }}>
                    <img src={member.image_url || 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&q=80'} alt={member.name} style={{ width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'top' }} />
                    <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,44,28,.72)', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '1rem', opacity: 0, transition: 'opacity .3s' }}
                      onMouseEnter={e => (e.currentTarget as any).style.opacity = 1}
                      onMouseLeave={e => (e.currentTarget as any).style.opacity = 0}>
                      {member.linkedin_url && <a href={member.linkedin_url} target="_blank" rel="noopener noreferrer" style={{ color: '#fff', fontSize: '.8rem', fontWeight: 700, background: 'rgba(255,255,255,.15)', borderRadius: '50%', width: '2.2rem', height: '2.2rem', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>in</a>}
                      {member.instagram_url && <a href={member.instagram_url} target="_blank" rel="noopener noreferrer" style={{ color: '#fff', fontSize: '.8rem', fontWeight: 700, background: 'rgba(255,255,255,.15)', borderRadius: '50%', width: '2.2rem', height: '2.2rem', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>ig</a>}
                    </div>
                  </div>
                  <div style={{ padding: '1.4rem' }}>
                    <div style={{ fontFamily: 'Playfair Display,serif', fontSize: '1.1rem', fontWeight: 600, marginBottom: '.25rem' }}>{member.name}</div>
                    <div style={{ fontSize: '.78rem', color: '#C89A1C', fontWeight: 600, letterSpacing: '.06em', textTransform: 'uppercase' }}>{member.role}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* NEWSLETTER + CTA */}
        <section style={{ padding: '4rem 0', background: '#eef6f1' }}>
          <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 2rem' }}>
            <div style={{ background: 'linear-gradient(135deg,#003d28,#1a7a54)', borderRadius: 14, padding: '4rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '2rem', flexWrap: 'wrap' }}>
              <div><h2 style={{ fontSize: '2rem', color: '#fff', marginBottom: '.6rem' }}>Stay Updated</h2><p style={{ color: 'rgba(255,255,255,.7)', fontSize: '.95rem' }}>Industry insights, project highlights, and company news delivered monthly.</p></div>
              {nlDone ? (
                <p style={{ color: '#e8b83a', fontWeight: 700 }}>✓ Subscribed! Thank you.</p>
              ) : (
                <div style={{ display: 'flex', gap: '.75rem', flex: 1, minWidth: 280, maxWidth: 480 }}>
                  <input type="email" value={nlEmail} onChange={e => setNlEmail(e.target.value)} placeholder="Enter your email address"
                    style={{ flex: 1, padding: '.85rem 1.2rem', borderRadius: 8, border: '1px solid rgba(255,255,255,.2)', fontFamily: 'Outfit,sans-serif', fontSize: '.9rem', background: 'rgba(255,255,255,.12)', color: '#fff', outline: 'none' }} />
                  <button onClick={subscribeNewsletter} style={{ padding: '.85rem 1.5rem', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.92rem', fontWeight: 600, cursor: 'pointer', border: 'none', background: 'linear-gradient(135deg,#C89A1C,#a07810)', color: '#fff' }}>Subscribe</button>
                </div>
              )}
            </div>
          </div>
        </section>
      </>
    );
  }

  // === CONTACT PAGE with full form ===
  if (page === 'contact') {
    const [form, setForm] = useState({ name: '', email: '', phone: '', service: '', location: '', budget: '', message: '' });
    const [submitting, setSubmitting] = useState(false);
    const [submitted, setSubmitted] = useState(false);
    const [error, setError] = useState('');

    const handleSubmit = async (e: React.FormEvent) => {
      e.preventDefault();
      setSubmitting(true); setError('');
      try {
        const res = await fetch('/api/leads', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...form, source: 'Website Contact Form' }),
        });
        if (!res.ok) throw new Error('Submission failed');
        setSubmitted(true);
      } catch { setError('Something went wrong. Please try WhatsApp instead.'); }
      finally { setSubmitting(false); }
    };

    return (
      <>
        {/* Page hero */}
        <div style={{ position: 'relative', padding: '9rem 2rem 5rem', overflow: 'hidden', minHeight: 420, display: 'flex', alignItems: 'center' }}>
          <img src="https://images.unsplash.com/photo-1559136555-9303baea8ebd?auto=format&fit=crop&w=1400&q=80" alt="" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover' }} />
          <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(105deg,rgba(0,40,25,.92),rgba(0,44,28,.82))' }} />
          <div style={{ position: 'relative', zIndex: 2, maxWidth: 700 }}>
            <span style={{ display: 'inline-block', color: '#e8b83a', fontSize: '.7rem', fontWeight: 700, letterSpacing: '.22em', textTransform: 'uppercase', marginBottom: '.9rem', padding: '.35rem .9rem', background: 'rgba(200,154,28,.15)', border: '1px solid rgba(200,154,28,.25)', borderRadius: 100 }}>Get In Touch</span>
            <h1 style={{ fontSize: 'clamp(2.4rem,5vw,4rem)', fontWeight: 700, color: '#fff', marginBottom: '1rem' }}>Let's Build Together</h1>
            <div style={{ width: '3rem', height: 3, background: '#C89A1C', margin: '1.5rem 0', borderRadius: 2 }} />
            <p style={{ fontSize: '1.05rem', color: 'rgba(255,255,255,.78)', lineHeight: 1.8 }}>Ready to discuss your project and deliver tailored solutions — contact us for a free, no-obligation consultation.</p>
          </div>
        </div>

        <section style={{ padding: '6rem 0' }}>
          <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 2rem' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '3fr 2fr', gap: '3rem' }}>
              {/* Form */}
              <div style={{ background: '#fff', border: '1px solid #d0e8dc', borderRadius: 14, padding: '2.75rem', boxShadow: '0 6px 24px rgba(0,60,40,.1)' }}>
                {submitted ? (
                  <div style={{ textAlign: 'center', padding: '3rem' }}>
                    <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>✅</div>
                    <h3 style={{ fontSize: '1.5rem', marginBottom: '.75rem' }}>Message Received!</h3>
                    <p style={{ color: '#6a8a7a' }}>Our team will contact you within 24 hours. You can also reach us directly on WhatsApp.</p>
                    <a href={waLink} target="_blank" rel="noopener noreferrer" style={{ display: 'inline-flex', alignItems: 'center', gap: '.5rem', marginTop: '1.5rem', background: '#25D366', color: '#fff', padding: '.75rem 1.5rem', borderRadius: 8, fontWeight: 600, textDecoration: 'none' }}>Chat on WhatsApp</a>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit}>
                    <h2 style={{ fontSize: '1.75rem', marginBottom: '1.75rem' }}>Send Us a Message</h2>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.4rem', marginBottom: '1.4rem' }}>
                      <div><label style={{ display: 'block', fontSize: '.82rem', fontWeight: 600, color: '#3a5546', marginBottom: '.5rem' }}>Full Name *</label><input required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Your full name" style={{ width: '100%', padding: '.82rem 1.1rem', border: '1.5px solid #d0e8dc', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.905rem', outline: 'none' }} /></div>
                      <div><label style={{ display: 'block', fontSize: '.82rem', fontWeight: 600, color: '#3a5546', marginBottom: '.5rem' }}>Email *</label><input required type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} placeholder="you@email.com" style={{ width: '100%', padding: '.82rem 1.1rem', border: '1.5px solid #d0e8dc', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.905rem', outline: 'none' }} /></div>
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.4rem', marginBottom: '1.4rem' }}>
                      <div><label style={{ display: 'block', fontSize: '.82rem', fontWeight: 600, color: '#3a5546', marginBottom: '.5rem' }}>Phone / WhatsApp</label><input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder={contact.phone || '+234 706 502 4741'} style={{ width: '100%', padding: '.82rem 1.1rem', border: '1.5px solid #d0e8dc', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.905rem', outline: 'none' }} /></div>
                      <div><label style={{ display: 'block', fontSize: '.82rem', fontWeight: 600, color: '#3a5546', marginBottom: '.5rem' }}>Service Needed *</label>
                        <select required value={form.service} onChange={e => setForm({ ...form, service: e.target.value })} style={{ width: '100%', padding: '.82rem 1.1rem', border: '1.5px solid #d0e8dc', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.905rem', outline: 'none', background: '#fff', appearance: 'none' }}>
                          <option value="">Select a service</option>
                          {data.services.map((s: any) => <option key={s.id}>{s.title}</option>)}
                          <option>Multiple Services</option>
                        </select>
                      </div>
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.4rem', marginBottom: '1.4rem' }}>
                      <div><label style={{ display: 'block', fontSize: '.82rem', fontWeight: 600, color: '#3a5546', marginBottom: '.5rem' }}>Project Location</label><input value={form.location} onChange={e => setForm({ ...form, location: e.target.value })} placeholder="State, City" style={{ width: '100%', padding: '.82rem 1.1rem', border: '1.5px solid #d0e8dc', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.905rem', outline: 'none' }} /></div>
                      <div><label style={{ display: 'block', fontSize: '.82rem', fontWeight: 600, color: '#3a5546', marginBottom: '.5rem' }}>Budget Range</label>
                        <select value={form.budget} onChange={e => setForm({ ...form, budget: e.target.value })} style={{ width: '100%', padding: '.82rem 1.1rem', border: '1.5px solid #d0e8dc', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.905rem', outline: 'none', background: '#fff', appearance: 'none' }}>
                          <option value="">Preferred range</option>
                          <option>Below ₦5M</option><option>₦5M – ₦20M</option><option>₦20M – ₦50M</option><option>₦50M – ₦100M</option><option>Above ₦100M</option>
                        </select>
                      </div>
                    </div>
                    <div style={{ marginBottom: '1.4rem' }}><label style={{ display: 'block', fontSize: '.82rem', fontWeight: 600, color: '#3a5546', marginBottom: '.5rem' }}>Project Description *</label><textarea required rows={5} value={form.message} onChange={e => setForm({ ...form, message: e.target.value })} placeholder="Tell us about your project — scope, size, timeline, and any specific requirements..." style={{ width: '100%', padding: '.82rem 1.1rem', border: '1.5px solid #d0e8dc', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.905rem', outline: 'none', resize: 'vertical' }} /></div>
                    {error && <p style={{ color: 'red', marginBottom: '1rem', fontSize: '.875rem' }}>{error}</p>}
                    <button type="submit" disabled={submitting} style={{ width: '100%', background: 'linear-gradient(135deg,#C89A1C,#a07810)', color: '#fff', border: 'none', padding: '1rem', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.95rem', fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '.6rem' }}>
                      {submitting ? 'Sending...' : 'Submit Request ✉'}
                    </button>
                  </form>
                )}
              </div>

              {/* Contact info */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                {[
                  { icon: '📍', label: 'Office Address', value: contact.address || 'Powa Plaza, Abraka, Delta State, Nigeria' },
                  { icon: '📞', label: 'Phone / WhatsApp', value: contact.phone || '+234 706 502 4741' },
                  { icon: '✉', label: 'Email', value: contact.email || 'info@jillglobalservices.com' },
                  { icon: '🕐', label: 'Business Hours', value: contact.business_hours || 'Mon–Fri: 9:00 AM – 6:00 PM (WAT)' },
                ].map(c => (
                  <div key={c.label} style={{ background: '#fff', border: '1px solid #d0e8dc', borderRadius: 14, padding: '1.5rem', display: 'flex', gap: '1rem', alignItems: 'flex-start', boxShadow: '0 2px 8px rgba(0,60,40,.07)' }}>
                    <div style={{ width: '3rem', height: '3rem', background: '#005C3D', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, fontSize: '1.2rem' }}>{c.icon}</div>
                    <div><div style={{ fontSize: '.7rem', fontWeight: 700, letterSpacing: '.12em', textTransform: 'uppercase', color: '#6a8a7a', marginBottom: '.25rem' }}>{c.label}</div><div style={{ fontSize: '.95rem', fontWeight: 500 }}>{c.value}</div></div>
                  </div>
                ))}
                
                {/* Social links */}
                <div style={{ background: '#005C3D', borderRadius: 14, padding: '1.5rem' }}>
                  <div style={{ fontSize: '.7rem', fontWeight: 700, letterSpacing: '.15em', textTransform: 'uppercase', color: 'rgba(255,255,255,.5)', marginBottom: '1rem' }}>Follow Us</div>
                  <div style={{ display: 'flex', gap: '.75rem', flexWrap: 'wrap' }}>
                    {[['Instagram', social.instagram, 'IG'], ['Facebook', social.facebook, 'FB'], ['LinkedIn', social.linkedin, 'in'], ['Twitter', social.twitter, 'TW'], ['YouTube', social.youtube, 'YT']].filter(([, url]) => url).map(([name, url, abbr]) => (
                      <a key={name as string} href={url as string} target="_blank" rel="noopener noreferrer" style={{ width: '2.5rem', height: '2.5rem', border: '1px solid rgba(255,255,255,.18)', borderRadius: 7, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '.72rem', fontWeight: 700, color: 'rgba(255,255,255,.7)', transition: 'all .2s' }}>{abbr as string}</a>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </>
    );
  }

  // === FAQ PAGE ===
  if (page === 'faq') {
    const [openFaq, setOpenFaq] = useState<string | null>(null);
    return (
      <>
        <PageHero title="Frequently Asked Questions" badge="FAQ" img="https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=1400&q=80" desc="Find answers to common questions about our services, processes, pricing, and how we work." />
        <section style={{ padding: '6rem 0' }}>
          <div style={{ maxWidth: 780, margin: '0 auto', padding: '0 2rem' }}>
            {data.faqs.map((f: any) => (
              <div key={f.id} style={{ marginBottom: '1rem', background: '#fff', border: `1.5px solid ${openFaq === f.id ? 'rgba(0,92,61,.4)' : '#d0e8dc'}`, borderRadius: 14, overflow: 'hidden', transition: 'border-color .3s' }}>
                <button onClick={() => setOpenFaq(openFaq === f.id ? null : f.id)} style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '1.5rem 1.75rem', cursor: 'pointer', background: 'none', border: 'none', textAlign: 'left', fontFamily: 'Playfair Display,serif', fontSize: '1.05rem', fontWeight: 600, color: openFaq === f.id ? '#005C3D' : '#152e22' }}>
                  {f.question}
                  <span style={{ width: '1.6rem', height: '1.6rem', borderRadius: '50%', background: openFaq === f.id ? '#005C3D' : '#eef6f1', border: `1.5px solid ${openFaq === f.id ? '#005C3D' : '#d0e8dc'}`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, transition: 'all .3s', transform: openFaq === f.id ? 'rotate(45deg)' : 'none', fontSize: '.8rem', color: openFaq === f.id ? '#fff' : '#6a8a7a' }}>+</span>
                </button>
                {openFaq === f.id && <div style={{ padding: '0 1.75rem 1.5rem', color: '#6a8a7a', lineHeight: 1.8, fontSize: '.925rem' }}>{f.answer}</div>}
              </div>
            ))}
          </div>
        </section>
        <section style={{ padding: '4rem 0', background: '#eef6f1', textAlign: 'center' }}>
          <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 2rem' }}>
            <h2 style={{ fontSize: '2.2rem', marginBottom: '1rem' }}>Still Have Questions?</h2>
            <p style={{ color: '#6a8a7a', maxWidth: 460, margin: '0 auto 2.5rem', lineHeight: 1.75 }}>Our team is ready to help — reach out and we will get back to you within 24 hours.</p>
            <button onClick={() => onNav('contact')} style={{ padding: '.85rem 2rem', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.92rem', fontWeight: 600, cursor: 'pointer', border: 'none', background: '#005C3D', color: '#fff' }}>Contact Us →</button>
          </div>
        </section>
      </>
    );
  }

  // === BLOG PAGE ===
  if (page === 'blog') {
    const catColors: Record<string, string> = { 'Industry Insights': '#005C3D', 'Interior Design': '#1a6a8c', 'Real Estate': '#b8860b', 'Sustainability': '#16a34a', 'Construction': '#555' };
    return (
      <>
        <PageHero title="Blog & News" badge="Insights" img="https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=1400&q=80" desc="Expert insights, industry trends, and updates from the Jill Global Services team." />
        <section style={{ padding: '6rem 0' }}>
          <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 2rem' }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(300px,1fr))', gap: '1.5rem' }}>
              {data.blog.map((post: any) => (
                <div key={post.id} style={{ background: '#fff', border: '1px solid #d0e8dc', borderRadius: 14, overflow: 'hidden', boxShadow: '0 2px 8px rgba(0,60,40,.07)', cursor: 'pointer', transition: 'all .3s' }}>
                  <div style={{ height: 200, overflow: 'hidden', position: 'relative' }}>
                    <img src={post.cover_image_url} alt={post.title} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    <span style={{ position: 'absolute', top: '1rem', left: '1rem', color: '#fff', fontSize: '.64rem', fontWeight: 700, letterSpacing: '.1em', textTransform: 'uppercase', padding: '.25rem .7rem', borderRadius: 100, background: catColors[post.category] || '#555' }}>{post.category}</span>
                  </div>
                  <div style={{ padding: '1.5rem' }}>
                    <div style={{ display: 'flex', gap: '1rem', fontSize: '.75rem', color: '#6a8a7a', marginBottom: '.9rem', flexWrap: 'wrap' }}>
                      <span>✍ {post.author}</span>
                      <span>📅 {new Date(post.published_at).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                      <span>🕐 {post.read_time}</span>
                    </div>
                    <h3 style={{ fontSize: '1.05rem', lineHeight: 1.4, marginBottom: '.7rem' }}>{post.title}</h3>
                    <p style={{ fontSize: '.845rem', color: '#6a8a7a', lineHeight: 1.7, marginBottom: '1.2rem' }}>{post.excerpt}</p>
                    <span style={{ fontSize: '.8rem', fontWeight: 700, color: '#005C3D' }}>Read More →</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      </>
    );
  }

  // === PORTFOLIO PAGE ===
  if (page === 'portfolio') {
    const [filter, setFilter] = useState('All');
    const categories = ['All', 'Completed', 'Ongoing', 'Residential', 'Commercial', 'Interior'];
    const filtered = filter === 'All' ? data.portfolio : data.portfolio.filter((p: any) => p.category?.includes(filter) || p.status?.includes(filter));
    return (
      <>
        <PageHero title="Portfolio" badge="Our Work" img="https://images.unsplash.com/photo-1486325212027-8081e485255e?auto=format&fit=crop&w=1400&q=80" desc="Precision, innovation, and excellence in every project — across residential, commercial, and interior sectors." />
        <section style={{ padding: '6rem 0' }}>
          <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 2rem' }}>
            <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '.75rem', marginBottom: '3rem' }}>
              {categories.map(cat => (
                <button key={cat} onClick={() => setFilter(cat)} style={{ padding: '.5rem 1.2rem', borderRadius: 100, border: `1.5px solid ${filter === cat ? '#005C3D' : '#d0e8dc'}`, background: filter === cat ? '#005C3D' : '#fff', fontSize: '.82rem', fontWeight: 600, color: filter === cat ? '#fff' : '#6a8a7a', cursor: 'pointer', transition: 'all .2s', boxShadow: filter === cat ? '0 4px 16px rgba(0,92,61,.3)' : 'none' }}>{cat}</button>
              ))}
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(300px,1fr))', gap: '1.5rem' }}>
              {filtered.map((p: any) => (
                <div key={p.id} style={{ borderRadius: 14, overflow: 'hidden', cursor: 'pointer', boxShadow: '0 2px 8px rgba(0,60,40,.07)', transition: 'all .35s' }}>
                  <div style={{ aspectRatio: '4/3', overflow: 'hidden', position: 'relative' }}>
                    <img src={p.image_url} alt={p.title} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to top,rgba(0,44,28,.92),transparent 50%)', opacity: 0, transition: 'opacity .35s' }} className="port-overlay" />
                    <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, padding: '1.5rem' }}>
                      <span style={{ display: 'inline-block', background: '#C89A1C', color: '#fff', fontSize: '.65rem', fontWeight: 700, letterSpacing: '.1em', textTransform: 'uppercase', padding: '.2rem .65rem', borderRadius: 100, marginBottom: '.5rem' }}>{p.category}</span>
                      <h3 style={{ color: '#fff', fontSize: '1.05rem', marginBottom: '.2rem' }}>{p.title}</h3>
                      <p style={{ color: 'rgba(255,255,255,.7)', fontSize: '.77rem' }}>{p.location} · {p.year}</p>
                    </div>
                  </div>
                  <div style={{ background: '#fff', padding: '1.25rem 1.5rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div><div style={{ fontSize: '.95rem', fontWeight: 700 }}>{p.title}</div><div style={{ fontSize: '.72rem', color: '#6a8a7a' }}>{p.description || p.category}</div></div>
                    <span style={{ fontSize: '.7rem', padding: '.2rem .6rem', borderRadius: 100, fontWeight: 600, background: p.status === 'Completed' ? '#e8f5e9' : '#fff3e0', color: p.status === 'Completed' ? '#2e7d32' : '#e65100' }}>{p.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      </>
    );
  }

  // === GALLERY PAGE ===
  if (page === 'gallery') {
    const [lb, setLb] = useState<string | null>(null);
    return (
      <>
        <PageHero title="Project Gallery" badge="Image Gallery" img="https://images.unsplash.com/photo-1541888946425-d81bb19240f5?auto=format&fit=crop&w=1400&q=80" desc="A visual journey through our finest work — from structural marvels to stunning interiors." />
        <section style={{ padding: '6rem 0' }}>
          <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 2rem' }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: '1rem' }}>
              {data.gallery.map((img: any, i: number) => (
                <div key={img.id} onClick={() => setLb(img.image_url)} style={{ borderRadius: 8, overflow: 'hidden', cursor: 'pointer', position: 'relative', aspectRatio: '1', transition: 'all .3s', gridRow: i % 3 === 0 ? 'span 2' : undefined }}>
                  <img src={img.image_url} alt={img.caption || `Gallery ${i + 1}`} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,44,28,.7)', display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: 0, transition: 'opacity .3s' }}
                    onMouseEnter={e => (e.currentTarget as any).style.opacity = 1}
                    onMouseLeave={e => (e.currentTarget as any).style.opacity = 0}>
                    <span style={{ color: '#fff', fontSize: '2rem' }}>⤢</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
        {lb && (
          <div onClick={() => setLb(null)} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,.95)', zIndex: 9000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '2rem' }}>
            <button onClick={() => setLb(null)} style={{ position: 'absolute', top: '1.5rem', right: '2rem', width: '3rem', height: '3rem', background: 'rgba(255,255,255,.12)', border: 'none', borderRadius: '50%', cursor: 'pointer', color: '#fff', fontSize: '1.4rem' }}>✕</button>
            <img src={lb} alt="Gallery" style={{ maxWidth: '90vw', maxHeight: '85vh', objectFit: 'contain', borderRadius: 8 }} />
          </div>
        )}
      </>
    );
  }

  // === ABOUT PAGE ===
  if (page === 'about') {
    const about = data.about || {};
    return (
      <>
        <PageHero title="Who We Are" badge="About Us" img="https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=1400&q=80" desc="A forward-thinking integrated services company specializing in construction, interior design, property development, and technical solutions across Nigeria." />
        <section style={{ padding: '6rem 0' }}>
          <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 2rem' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '4rem', alignItems: 'center' }}>
              <div style={{ borderRadius: 14, overflow: 'hidden', aspectRatio: '4/5', position: 'relative' }}>
                <img src={about.about_image_url || 'https://images.unsplash.com/photo-1486325212027-8081e485255e?w=700&q=80'} alt="About" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                <div style={{ position: 'absolute', bottom: '1.5rem', right: '1.5rem', background: '#C89A1C', color: '#fff', padding: '1.25rem 1.75rem', borderRadius: 12, textAlign: 'center' }}>
                  <div style={{ fontFamily: 'Playfair Display,serif', fontSize: '2.5rem', fontWeight: 700, lineHeight: 1 }}>{about.years_experience || '10+'}</div>
                  <div style={{ fontSize: '.72rem', fontWeight: 600, letterSpacing: '.05em', marginTop: '.2rem' }}>Years Excellence</div>
                </div>
              </div>
              <div>
                <span style={{ fontSize: '.72rem', fontWeight: 700, letterSpacing: '.22em', textTransform: 'uppercase', color: '#C89A1C', display: 'block', marginBottom: '.75rem' }}>Our Story</span>
                <h2 style={{ fontSize: '2.2rem', marginBottom: '1.25rem' }}>{about.story_heading || 'At the Intersection of Engineering, Design & Innovation'}</h2>
                <p style={{ color: '#6a8a7a', lineHeight: 1.85, marginBottom: '1rem' }}>{about.story_body1}</p>
                <p style={{ color: '#6a8a7a', lineHeight: 1.85, marginBottom: '1.5rem' }}>{about.story_body2}</p>
                {about.story_quote && <blockquote style={{ borderLeft: '4px solid #C89A1C', paddingLeft: '1.25rem', fontStyle: 'italic', color: '#3a5546', fontWeight: 500, lineHeight: 1.7, marginBottom: '2rem' }}>{about.story_quote}</blockquote>}
                <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
                  <button onClick={() => onNav('contact')} style={{ padding: '.85rem 2rem', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.92rem', fontWeight: 600, cursor: 'pointer', border: 'none', background: '#005C3D', color: '#fff' }}>Start a Project</button>
                  <button onClick={() => onNav('services')} style={{ padding: '.85rem 2rem', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.92rem', fontWeight: 600, cursor: 'pointer', background: 'transparent', color: '#005C3D', border: '1.5px solid #d0e8dc' }}>Our Services</button>
                </div>
              </div>
            </div>
          </div>
        </section>
        {/* Vision & Mission */}
        <section style={{ padding: '6rem 0', background: '#eef6f1' }}>
          <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 2rem' }}>
            <div style={{ textAlign: 'center', marginBottom: '3.5rem' }}>
              <span style={{ fontSize: '.72rem', fontWeight: 700, letterSpacing: '.22em', textTransform: 'uppercase', color: '#C89A1C', display: 'block', marginBottom: '.75rem' }}>Vision & Mission</span>
              <h2 style={{ fontSize: '2.5rem', fontWeight: 600 }}>What Drives Us Forward</h2>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
              <div style={{ background: '#fff', border: '1px solid #d0e8dc', borderRadius: 14, padding: '2.5rem', boxShadow: '0 2px 8px rgba(0,60,40,.07)' }}>
                <div style={{ width: '3.5rem', height: '3.5rem', background: '#005C3D', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '1.5rem', fontSize: '1.5rem' }}>👁</div>
                <h3 style={{ fontSize: '1.5rem', marginBottom: '.75rem' }}>Our Vision</h3>
                <p style={{ color: '#6a8a7a', lineHeight: 1.8 }}>{about.vision_text}</p>
              </div>
              <div style={{ background: '#fff', border: '1px solid #d0e8dc', borderRadius: 14, padding: '2.5rem', boxShadow: '0 2px 8px rgba(0,60,40,.07)' }}>
                <div style={{ width: '3.5rem', height: '3.5rem', background: '#C89A1C', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '1.5rem', fontSize: '1.5rem' }}>🎯</div>
                <h3 style={{ fontSize: '1.5rem', marginBottom: '.75rem' }}>Our Mission</h3>
                <p style={{ color: '#6a8a7a', lineHeight: 1.8 }}>{about.mission_text}</p>
              </div>
            </div>
          </div>
        </section>
      </>
    );
  }

  // === SERVICES PAGE ===
  if (page === 'services') {
    return (
      <>
        <PageHero title="Comprehensive Solutions" badge="Our Services" img="https://images.unsplash.com/photo-1541888946425-d81bb19240f5?auto=format&fit=crop&w=1400&q=80" desc="From concept to completion, integrated services covering every aspect of construction, design, and property development." />
        {data.services.map((s: any, i: number) => (
          <section key={s.id} style={{ padding: '6rem 0', background: i % 2 === 1 ? '#eef6f1' : '#f8faf9' }}>
            <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 2rem' }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '4rem', alignItems: 'center', direction: i % 2 === 1 ? 'rtl' : 'ltr' } as any}>
                <div style={{ direction: 'ltr' }}>
                  <h2 style={{ fontSize: '2rem', marginBottom: '1rem' }}>{s.title}</h2>
                  <p style={{ color: '#6a8a7a', lineHeight: 1.8, marginBottom: '1.5rem' }}>{s.description}</p>
                  {s.features && (
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '.7rem', marginBottom: '1.5rem' }}>
                      {(Array.isArray(s.features) ? s.features : JSON.parse(s.features || '[]')).map((f: string) => (
                        <div key={f} style={{ display: 'flex', alignItems: 'center', gap: '.6rem', fontSize: '.875rem' }}><span style={{ color: '#C89A1C' }}>✓</span>{f}</div>
                      ))}
                    </div>
                  )}
                  <a href={`https://wa.me/${contact.whatsapp || '2347065024741'}?text=I%20am%20interested%20in%20${encodeURIComponent(s.title)}`} target="_blank" rel="noopener noreferrer" style={{ display: 'inline-flex', alignItems: 'center', gap: '.55rem', padding: '.85rem 2rem', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.92rem', fontWeight: 600, cursor: 'pointer', border: 'none', background: '#005C3D', color: '#fff', textDecoration: 'none' }}>Get Started →</a>
                </div>
                <div style={{ borderRadius: 14, overflow: 'hidden', aspectRatio: '4/3', direction: 'ltr' }}>
                  <img src={s.image_url} alt={s.title} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                </div>
              </div>
            </div>
          </section>
        ))}
      </>
    );
  }

  // === CAREERS PAGE ===
  if (page === 'careers') {
    return (
      <>
        <PageHero title="Join Our Team" badge="Careers" img="https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1400&q=80" desc="We are always looking for talented professionals passionate about construction, design and innovation." />
        <section style={{ padding: '6rem 0', background: '#eef6f1' }}>
          <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 2rem' }}>
            <div style={{ textAlign: 'center', marginBottom: '3.5rem' }}>
              <span style={{ fontSize: '.72rem', fontWeight: 700, letterSpacing: '.22em', textTransform: 'uppercase', color: '#C89A1C', display: 'block', marginBottom: '.75rem' }}>Open Positions</span>
              <h2 style={{ fontSize: '2.5rem', fontWeight: 600 }}>Current Openings</h2>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              {data.jobs.map((j: any) => (
                <div key={j.id} style={{ background: '#fff', border: '1px solid #d0e8dc', borderRadius: 14, padding: '2rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between', boxShadow: '0 2px 8px rgba(0,60,40,.07)', flexWrap: 'wrap', gap: '1.5rem' }}>
                  <div>
                    <span style={{ display: 'inline-block', background: '#e6f4ee', color: '#005C3D', fontSize: '.68rem', fontWeight: 700, letterSpacing: '.1em', textTransform: 'uppercase', padding: '.2rem .65rem', borderRadius: 100, marginBottom: '.6rem' }}>{j.department}</span>
                    <div style={{ fontFamily: 'Playfair Display,serif', fontSize: '1.15rem', fontWeight: 600, marginBottom: '.5rem' }}>{j.title}</div>
                    <div style={{ display: 'flex', gap: '.6rem', flexWrap: 'wrap', fontSize: '.75rem', color: '#6a8a7a' }}>
                      <span>📍 {j.location}</span><span>🕐 {j.job_type}</span>
                    </div>
                    {j.description && <p style={{ fontSize: '.855rem', color: '#6a8a7a', marginTop: '.7rem', lineHeight: 1.65, maxWidth: 580 }}>{j.description}</p>}
                  </div>
                  <button onClick={() => onNav('contact')} style={{ background: '#005C3D', color: '#fff', padding: '.65rem 1.5rem', borderRadius: 8, fontSize: '.875rem', fontWeight: 600, border: 'none', cursor: 'pointer', whiteSpace: 'nowrap' }}>Apply Now</button>
                </div>
              ))}
            </div>
            <p style={{ textAlign: 'center', marginTop: '2.5rem', color: '#6a8a7a', fontSize: '.9rem' }}>
              Don't see your role? Send your CV to <a href={`mailto:${contact.email}`} style={{ color: '#C89A1C' }}>{contact.email || 'careers@jillglobalservices.com'}</a>
            </p>
          </div>
        </section>
      </>
    );
  }

  // Fallback
  return (
    <div style={{ minHeight: '70vh', display: 'flex', alignItems: 'center', justifyContent: 'center', textAlign: 'center', padding: '5rem 2rem' }}>
      <div>
        <div style={{ fontFamily: 'Playfair Display,serif', fontSize: '9rem', fontWeight: 700, color: '#e6f4ee', lineHeight: 1 }}>404</div>
        <h2 style={{ fontSize: '2rem', marginBottom: '1rem' }}>Page Not Found</h2>
        <button onClick={() => onNav('home')} style={{ padding: '.85rem 2rem', borderRadius: 8, fontFamily: 'Outfit,sans-serif', fontSize: '.92rem', fontWeight: 600, cursor: 'pointer', border: 'none', background: '#005C3D', color: '#fff' }}>← Back to Home</button>
      </div>
    </div>
  );
}

// ─── Shared Page Hero ────────────────────────────────────────
function PageHero({ title, badge, img, desc }: { title: string; badge: string; img: string; desc: string }) {
  return (
    <div style={{ position: 'relative', padding: '9rem 2rem 5rem', overflow: 'hidden', minHeight: 420, display: 'flex', alignItems: 'center' }}>
      <img src={img} alt="" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover' }} />
      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(105deg,rgba(0,40,25,.92),rgba(0,44,28,.82))' }} />
      <div style={{ position: 'relative', zIndex: 2, maxWidth: 700 }}>
        <span style={{ display: 'inline-block', color: '#e8b83a', fontSize: '.7rem', fontWeight: 700, letterSpacing: '.22em', textTransform: 'uppercase', marginBottom: '.9rem', padding: '.35rem .9rem', background: 'rgba(200,154,28,.15)', border: '1px solid rgba(200,154,28,.25)', borderRadius: 100 }}>{badge}</span>
        <h1 style={{ fontSize: 'clamp(2.4rem,5vw,4rem)', fontWeight: 700, color: '#fff', marginBottom: '1rem' }}>{title}</h1>
        <div style={{ width: '3rem', height: 3, background: '#C89A1C', margin: '1.5rem 0', borderRadius: 2 }} />
        <p style={{ fontSize: '1.05rem', color: 'rgba(255,255,255,.78)', lineHeight: 1.8 }}>{desc}</p>
      </div>
    </div>
  );
}

// ─── Footer ─────────────────────────────────────────────────
function Footer({ settings, onNav }: { settings: any; onNav: (p: string) => void }) {
  const contact = settings?.contact || {};
  const social = settings?.social || {};
  const branding = settings?.branding || {};
  const [nlEmail, setNlEmail] = useState('');
  const [nlDone, setNlDone] = useState(false);

  const socialLinks = [
    ['LinkedIn', social.linkedin, 'in'],
    ['Twitter', social.twitter, 'tw'],
    ['Facebook', social.facebook, 'fb'],
    ['Instagram', social.instagram, 'ig'],
    ['YouTube', social.youtube, 'yt'],
  ].filter(([, url]) => url);

  return (
    <footer style={{ background: '#003d28', color: '#fff', padding: '5rem 0 0' }}>
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 2rem' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '2.2fr 1fr 1fr 1fr', gap: '3.5rem', paddingBottom: '3.5rem', borderBottom: '1px solid rgba(255,255,255,.1)' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '.85rem', marginBottom: '1.1rem' }}>
              <div style={{ width: 46, height: 46, background: 'linear-gradient(135deg,#C89A1C,#a07810)', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Playfair Display,serif', fontWeight: 700, fontSize: '1.2rem', color: '#fff' }}>JG</div>
              <div><div style={{ fontFamily: 'Playfair Display,serif', fontWeight: 700, fontSize: '1.1rem' }}>{branding.company_name || 'Jill Global Services Ltd'}</div><div style={{ fontFamily: 'Outfit,sans-serif', fontSize: '.62rem', fontWeight: 400, letterSpacing: '.15em', textTransform: 'uppercase', color: 'rgba(255,255,255,.4)', marginTop: '.1rem' }}>{branding.tagline || 'Building Landmark Projects'}</div></div>
            </div>
            <p style={{ fontSize: '.875rem', color: 'rgba(255,255,255,.55)', lineHeight: 1.75, maxWidth: 280, marginBottom: '1.75rem' }}>Nigeria's leading integrated construction, design & property solutions company delivering innovation from concept to completion since 2015.</p>
            <div style={{ display: 'flex', gap: '.75rem' }}>
              {socialLinks.map(([name, url, abbr]) => (
                <a key={name as string} href={url as string} target="_blank" rel="noopener noreferrer"
                  style={{ width: '2.2rem', height: '2.2rem', border: '1px solid rgba(255,255,255,.18)', borderRadius: 7, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '.72rem', fontWeight: 700, color: 'rgba(255,255,255,.55)', cursor: 'pointer', transition: 'all .2s', textDecoration: 'none' }}>
                  {abbr as string}
                </a>
              ))}
            </div>
          </div>
          <div>
            <div style={{ fontSize: '.68rem', fontWeight: 700, letterSpacing: '.22em', textTransform: 'uppercase', color: '#e8b83a', marginBottom: '1.4rem' }}>Services</div>
            <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '.7rem' }}>
              {['Construction', 'Interior Design', 'Property Development', 'Technical Solutions', 'General Contracting'].map(s => (
                <li key={s}><a onClick={() => onNav('services')} style={{ fontSize: '.875rem', color: 'rgba(255,255,255,.55)', cursor: 'pointer' }}>→ {s}</a></li>
              ))}
            </ul>
          </div>
          <div>
            <div style={{ fontSize: '.68rem', fontWeight: 700, letterSpacing: '.22em', textTransform: 'uppercase', color: '#e8b83a', marginBottom: '1.4rem' }}>Company</div>
            <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '.7rem' }}>
              {[['About Us', 'about'], ['Portfolio', 'portfolio'], ['Gallery', 'gallery'], ['Blog & News', 'blog'], ['Careers', 'careers']].map(([label, pg]) => (
                <li key={pg}><a onClick={() => onNav(pg)} style={{ fontSize: '.875rem', color: 'rgba(255,255,255,.55)', cursor: 'pointer' }}>→ {label}</a></li>
              ))}
            </ul>
          </div>
          <div>
            <div style={{ fontSize: '.68rem', fontWeight: 700, letterSpacing: '.22em', textTransform: 'uppercase', color: '#e8b83a', marginBottom: '1.4rem' }}>Contact</div>
            <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '.7rem' }}>
              <li><a href={`tel:${contact.phone}`} style={{ fontSize: '.875rem', color: 'rgba(255,255,255,.55)', textDecoration: 'none' }}>→ {contact.phone}</a></li>
              <li><a href={`mailto:${contact.email}`} style={{ fontSize: '.875rem', color: 'rgba(255,255,255,.55)', textDecoration: 'none' }}>→ {contact.email}</a></li>
              <li><a onClick={() => onNav('faq')} style={{ fontSize: '.875rem', color: 'rgba(255,255,255,.55)', cursor: 'pointer' }}>→ FAQ</a></li>
              <li><a onClick={() => onNav('contact')} style={{ fontSize: '.875rem', color: 'rgba(255,255,255,.55)', cursor: 'pointer' }}>→ Get a Quote</a></li>
            </ul>
          </div>
        </div>
        <div style={{ padding: '1.75rem 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
          <div style={{ fontSize: '.78rem', color: 'rgba(255,255,255,.35)' }}>© {new Date().getFullYear()} {branding.company_name || 'Jill Global Services Ltd'}. All rights reserved. Abraka, Delta State, Nigeria.</div>
          <div style={{ display: 'flex', gap: '1.5rem' }}>
            <Link href="/admin" style={{ fontSize: '.78rem', color: 'rgba(255,255,255,.35)', textDecoration: 'none' }}>Admin</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}

// ─── MAIN PAGE ───────────────────────────────────────────────
export default function Website({ siteData }: { siteData: SiteData }) {
  const [page, setPage] = useState('home');
  const { settings } = siteData;
  const contact = settings?.contact || {};
  const seo = settings?.seo || {};

  const navigate = (p: string) => {
    setPage(p);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      <Head>
        <title>{seo.title || 'Jill Global Services Ltd | Building Landmark Projects'}</title>
        <meta name="description" content={seo.description || "Nigeria's premier construction, interior design & property development company."} />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        {seo.og_image && <meta property="og:image" content={seo.og_image} />}
      </Head>

      <Nav settings={settings} currentPage={page} onNav={navigate} />

      <main style={{ paddingTop: 74 }}>
        <PageRenderer page={page} data={siteData} onNav={navigate} settings={settings} />
      </main>

      <Footer settings={settings} onNav={navigate} />
      <WAFloat whatsapp={contact.whatsapp || '2347065024741'} />
    </>
  );
}

export const getStaticProps: GetStaticProps = async () => {
  try {
    const [settings, hero, about, services, portfolio, gallery, team, testimonials, blog, faqs, jobs] = await Promise.all([
      getSiteSettings(),
      getHeroSection(),
      getAboutSection(),
      getServices(),
      getPortfolio(),
      getGallery(),
      getTeam(),
      getTestimonials(),
      getBlogPosts(),
      getFaqs(),
      getJobs(),
    ]);

    return {
      props: {
        siteData: { settings, hero, about, services, portfolio, gallery, team, testimonials, blog, faqs, jobs }
      },
      revalidate: 60, // ISR: revalidate every 60 seconds
    };
  } catch (err) {
    console.error('Error fetching site data:', err);
    return {
      props: {
        siteData: { settings: {}, hero: {}, about: {}, services: [], portfolio: [], gallery: [], team: [], testimonials: [], blog: [], faqs: [], jobs: [] }
      },
      revalidate: 30,
    };
  }
};
