import type { NextApiRequest, NextApiResponse } from 'next';
import { supabaseAdmin } from '@/lib/supabase';
import { createLead } from '@/lib/airtable';
import { triggerN8nWebhook } from '@/lib/automation';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'POST') {
    const { name, email, phone, service, location, budget, message, source } = req.body;
    if (!name || !phone) return res.status(400).json({ error: 'Name and phone are required' });

    try {
      // 1. Save to Supabase
      const { data: lead, error } = await supabaseAdmin()
        .from('leads').insert([{ name, email, phone, service, location, budget, message, source: source || 'Website Contact Form', status: 'New' }])
        .select().single();
      if (error) throw error;

      // 2. Sync to Airtable CRM (async, don't block)
      let airtableId: string | undefined;
      try {
        const atRecord = await createLead({ name, email, phone, service, location, budget, message, source });
        airtableId = atRecord?.id;
        if (airtableId && lead?.id) {
          await supabaseAdmin().from('leads').update({ airtable_id: airtableId }).eq('id', lead.id);
        }
      } catch (atErr) { console.error('Airtable sync error:', atErr); }

      // 3. Trigger n8n WhatsApp notification
      await triggerN8nWebhook({
        event: 'new_lead',
        payload: { id: lead?.id, name, email, phone, service, location, budget, message, airtable_id: airtableId }
      });

      return res.status(201).json({ success: true, id: lead?.id });
    } catch (err: any) {
      console.error('Lead submission error:', err);
      return res.status(500).json({ error: err.message || 'Submission failed' });
    }
  }

  if (req.method === 'GET') {
    // Admin only
    const auth = req.headers.authorization;
    if (!auth) return res.status(401).json({ error: 'Unauthorized' });
    const { data } = await supabaseAdmin().from('leads').select('*').order('created_at', { ascending: false });
    return res.status(200).json(data || []);
  }
  
  res.status(405).end();
}
