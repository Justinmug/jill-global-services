import type { NextApiRequest, NextApiResponse } from 'next';
import { supabaseAdmin, supabase } from '@/lib/supabase';
import { verifyAdminToken } from '@/lib/auth';

const PUBLIC_TABLES = ['services','portfolio_projects','gallery_images','team_members','testimonials','blog_posts','faq_items','job_openings','hero_section','about_section'];
const SETTINGS_TABLES = ['site_settings'];
const ADMIN_TABLES = ['leads','newsletter_subscribers'];

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { table } = req.query as { table: string };
  const allAllowed = [...PUBLIC_TABLES, ...SETTINGS_TABLES, ...ADMIN_TABLES];
  if (!allAllowed.includes(table)) return res.status(404).json({ error: 'Table not found' });

  // GET - public read
  if (req.method === 'GET') {
    const isAdmin = ADMIN_TABLES.includes(table);
    if (isAdmin) {
      const auth = req.headers.authorization;
      if (!auth || !verifyAdminToken(auth.replace('Bearer ', ''))) {
        return res.status(401).json({ error: 'Unauthorized' });
      }
    }
    const client = isAdmin ? supabaseAdmin() : supabase;
    const { id } = req.query;
    let query = client.from(table).select('*');
    if (id) query = (query as any).eq('id', id);
    const { data, error } = await query;
    if (error) return res.status(500).json({ error: error.message });
    return res.status(200).json(data);
  }

  // POST/PUT/PATCH/DELETE - admin only
  const auth = req.headers.authorization;
  if (!auth || !verifyAdminToken(auth.replace('Bearer ', ''))) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  if (req.method === 'POST') {
    const { data, error } = await supabaseAdmin().from(table).insert([req.body]).select();
    if (error) return res.status(500).json({ error: error.message });
    return res.status(201).json(data?.[0]);
  }

  if (req.method === 'PUT' || req.method === 'PATCH') {
    const { id, ...body } = req.body;
    if (!id) return res.status(400).json({ error: 'id required' });
    body.updated_at = new Date().toISOString();
    const { data, error } = await supabaseAdmin().from(table).update(body).eq('id', id).select();
    if (error) return res.status(500).json({ error: error.message });
    return res.status(200).json(data?.[0]);
  }

  if (req.method === 'DELETE') {
    const { id } = req.query;
    if (!id) return res.status(400).json({ error: 'id required' });
    const { error } = await supabaseAdmin().from(table).delete().eq('id', id as string);
    if (error) return res.status(500).json({ error: error.message });
    return res.status(200).json({ deleted: true });
  }

  res.status(405).end();
}
