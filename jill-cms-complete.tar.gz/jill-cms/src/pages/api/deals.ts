import type { NextApiRequest, NextApiResponse } from 'next';
import { fetchAirtableRecords, updateAirtableRecord } from '@/lib/airtable';

const TABLE_ID = process.env.AIRTABLE_DEALS_TABLE_ID!;

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  try {
    if (req.method === 'GET') {
      const data = await fetchAirtableRecords(TABLE_ID, {
        sort: JSON.stringify([{ field: 'Created', direction: 'desc' }]),
        maxRecords: '100',
      });
      return res.status(200).json(data);
    }

    if (req.method === 'PATCH') {
      const { recordId, ...fields } = req.body;
      if (!recordId) return res.status(400).json({ error: 'recordId is required' });
      const record = await updateAirtableRecord(TABLE_ID, recordId, fields);
      return res.status(200).json(record);
    }

    res.setHeader('Allow', ['GET', 'PATCH']);
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Internal server error';
    return res.status(500).json({ error: message });
  }
}
