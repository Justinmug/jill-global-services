import type { NextApiRequest, NextApiResponse } from 'next';
import { supabase, supabaseAdmin } from '@/lib/supabase';
import { verifyAdminToken } from '@/lib/auth';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    const { data } = await supabase.from('site_settings').select('key, value');
    const settings = (data || []).reduce((acc: Record<string, any>, row) => {
      acc[row.key] = row.value;
      return acc;
    }, {});
    return res.status(200).json(settings);
  }

  if (req.method === 'PUT') {
    const auth = req.headers.authorization;
    if (!auth || !verifyAdminToken(auth.replace('Bearer ', ''))) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    const { key, value } = req.body;
    if (!key) return res.status(400).json({ error: 'key required' });
    const { data, error } = await supabaseAdmin()
      .from('site_settings').upsert([{ key, value, updated_at: new Date().toISOString() }], { onConflict: 'key' }).select();
    if (error) return res.status(500).json({ error: error.message });
    return res.status(200).json(data?.[0]);
  }

  res.status(405).end();
}
