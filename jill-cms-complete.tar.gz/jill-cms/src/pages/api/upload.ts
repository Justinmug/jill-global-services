import type { NextApiRequest, NextApiResponse } from 'next';
import { supabaseAdmin } from '@/lib/supabase';
import { verifyAdminToken } from '@/lib/auth';

export const config = { api: { bodyParser: { sizeLimit: '10mb' } } };

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end();
  
  const auth = req.headers.authorization;
  if (!auth || !verifyAdminToken(auth.replace('Bearer ', ''))) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  try {
    const { imageData, filename, mimeType, folder = 'general' } = req.body;
    if (!imageData || !filename) return res.status(400).json({ error: 'imageData and filename required' });
    
    // imageData is base64
    const base64 = imageData.replace(/^data:[^;]+;base64,/, '');
    const buffer = Buffer.from(base64, 'base64');
    const path = `${folder}/${Date.now()}-${filename}`;
    
    const { error } = await supabaseAdmin().storage.from('site-images').upload(path, buffer, {
      contentType: mimeType || 'image/jpeg',
      upsert: true,
    });
    if (error) throw error;
    
    const { data: urlData } = supabaseAdmin().storage.from('site-images').getPublicUrl(path);
    return res.status(200).json({ url: urlData.publicUrl, path });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
}
