import type { NextApiRequest, NextApiResponse } from 'next';
import { verifyAdminPassword, generateAdminToken, verifyAdminToken, getTokenFromRequest } from '@/lib/auth';

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'POST') {
    const { password } = req.body;
    if (!verifyAdminPassword(password)) {
      return res.status(401).json({ error: 'Invalid password' });
    }
    const token = generateAdminToken();
    return res.status(200).json({ token });
  }
  if (req.method === 'GET') {
    const token = getTokenFromRequest(req as any);
    if (!token || !verifyAdminToken(token)) {
      return res.status(401).json({ valid: false });
    }
    return res.status(200).json({ valid: true });
  }
  res.status(405).end();
}
