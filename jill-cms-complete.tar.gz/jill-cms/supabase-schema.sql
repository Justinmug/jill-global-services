
-- ============================================================
-- JILL GLOBAL SERVICES - COMPLETE SUPABASE SCHEMA
-- Run this in your Supabase SQL Editor
-- ============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
-- SITE SETTINGS (branding, contact, social, SEO)
-- ============================================================
CREATE TABLE IF NOT EXISTS site_settings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  key TEXT UNIQUE NOT NULL,
  value JSONB NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Insert default settings
INSERT INTO site_settings (key, value) VALUES
('branding', '{
  "company_name": "Jill Global Services Ltd",
  "tagline": "Building Landmark Projects",
  "logo_url": "",
  "favicon_url": "",
  "primary_color": "#005C3D",
  "accent_color": "#C89A1C"
}'::jsonb),
('contact', '{
  "phone": "+234 706 502 4741",
  "whatsapp": "2347065024741",
  "email": "info@jillglobalservices.com",
  "address": "Powa Plaza, Opposite Big Market, Abraka, Delta State, Nigeria",
  "business_hours": "Mon-Fri: 9:00 AM – 6:00 PM (WAT)",
  "google_maps_url": ""
}'::jsonb),
('social', '{
  "instagram": "https://instagram.com/jillglobalservices",
  "facebook": "https://facebook.com/jillglobalservices",
  "twitter": "https://twitter.com/jillglobal",
  "linkedin": "https://linkedin.com/company/jill-global-services",
  "youtube": "",
  "tiktok": ""
}'::jsonb),
('seo', '{
  "title": "Jill Global Services Ltd | Building Landmark Projects",
  "description": "Nigeria premier integrated construction, interior design & property solutions company. Engineering excellence since 2015.",
  "keywords": "construction Nigeria, interior design, property development, Delta State",
  "og_image": ""
}'::jsonb),
('automation', '{
  "n8n_webhook_url": "https://flow.jillglobalservices.com/webhook/contact-form",
  "whatsapp_notification_number": "2347065024741",
  "admin_email": "info@jillglobalservices.com"
}'::jsonb)
ON CONFLICT (key) DO NOTHING;

-- ============================================================
-- HERO SECTION
-- ============================================================
CREATE TABLE IF NOT EXISTS hero_section (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  badge_text TEXT DEFAULT 'Engineering Excellence Since 2015',
  heading_line1 TEXT DEFAULT 'Building Landmark',
  heading_line2 TEXT DEFAULT 'Projects. Creating',
  heading_emphasis TEXT DEFAULT 'Timeless Spaces.',
  subtext TEXT DEFAULT 'Nigeria''s leading integrated construction, interior design & property solutions company delivering innovative, sustainable results across the continent.',
  cta_primary_text TEXT DEFAULT 'Request a Consultation',
  cta_secondary_text TEXT DEFAULT 'View Our Projects',
  bg_image_url TEXT DEFAULT 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=1600&q=85',
  stat1_value TEXT DEFAULT '150+',
  stat1_label TEXT DEFAULT 'Projects Delivered',
  stat2_value TEXT DEFAULT '50+',
  stat2_label TEXT DEFAULT 'Happy Clients',
  stat3_value TEXT DEFAULT '10+',
  stat3_label TEXT DEFAULT 'Years Experience',
  stat4_value TEXT DEFAULT '100%',
  stat4_label TEXT DEFAULT 'Quality Commitment',
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
INSERT INTO hero_section DEFAULT VALUES ON CONFLICT DO NOTHING;

-- ============================================================
-- ABOUT SECTION
-- ============================================================
CREATE TABLE IF NOT EXISTS about_section (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  story_heading TEXT DEFAULT 'At the Intersection of Engineering, Design & Innovation',
  story_body1 TEXT DEFAULT 'We operate at the intersection of engineering, design, and innovation — delivering projects that meet global standards while responding to local market realities.',
  story_body2 TEXT DEFAULT 'Founded in 2015 in Abraka, Delta State, our team has grown to serve clients across Nigeria with a relentless commitment to quality and client satisfaction.',
  story_quote TEXT DEFAULT 'Every project is more than a structure — it is an investment, a vision, and a legacy.',
  years_experience TEXT DEFAULT '10+',
  about_image_url TEXT DEFAULT 'https://images.unsplash.com/photo-1486325212027-8081e485255e?auto=format&fit=crop&w=700&q=80',
  vision_text TEXT DEFAULT 'To become the leading integrated construction and property solutions company in Africa, recognized for excellence, innovation, and sustainable impact on communities.',
  mission_text TEXT DEFAULT 'To deliver world-class construction and design solutions through innovation, technology, and professional expertise — creating long-term value for all stakeholders.',
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
INSERT INTO about_section DEFAULT VALUES ON CONFLICT DO NOTHING;

-- ============================================================
-- SERVICES
-- ============================================================
CREATE TABLE IF NOT EXISTS services (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sort_order INT DEFAULT 0,
  title TEXT NOT NULL,
  description TEXT,
  image_url TEXT,
  icon_type TEXT DEFAULT 'construction',
  features JSONB DEFAULT '[]'::jsonb,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO services (sort_order, title, description, image_url, icon_type, features) VALUES
(1, 'Construction & Engineering', 'End-to-end building solutions for residential, commercial & industrial projects built with precision and safety.', 'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?auto=format&fit=crop&w=700&q=80', 'construction', '["Residential buildings", "Commercial facilities", "Industrial projects", "Renovation works", "Civil engineering", "Project management"]'::jsonb),
(2, 'Interior Design & Fit-Out', 'Modern, functional, aesthetic interior solutions with 3D visualization — tailored to your lifestyle and business.', 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=700&q=80', 'design', '["Residential interiors", "Corporate interiors", "Space planning", "3D visualization", "Custom furniture", "Premium finishes"]'::jsonb),
(3, 'Property Development', 'Strategic property development, investment advisory & facility management for maximum long-term returns.', 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=700&q=80', 'property', '["Property development", "Real estate consultancy", "Property management", "Land acquisition", "Investment advisory", "Real estate marketing"]'::jsonb),
(4, 'Technical & Digital Solutions', 'Smart building systems, IoT integration & digital project management platforms for efficient delivery.', 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=700&q=80', 'tech', '["Smart building systems", "Automation & IoT", "Digital project mgmt", "AI workflow tools", "Corporate websites", "BIM & 3D modelling"]'::jsonb),
(5, 'General Contracting', 'Reliable material sourcing, logistics & turnkey project execution with robust quality assurance.', 'https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?auto=format&fit=crop&w=700&q=80', 'contracting', '["Material sourcing", "Logistics management", "Turnkey delivery", "Quality assurance", "Subcontractor mgmt", "Cost control"]'::jsonb)
ON CONFLICT DO NOTHING;

-- ============================================================
-- PORTFOLIO PROJECTS
-- ============================================================
CREATE TABLE IF NOT EXISTS portfolio_projects (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sort_order INT DEFAULT 0,
  title TEXT NOT NULL,
  category TEXT,
  location TEXT,
  year TEXT,
  description TEXT,
  image_url TEXT,
  status TEXT DEFAULT 'Completed',
  is_featured BOOLEAN DEFAULT false,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO portfolio_projects (sort_order, title, category, location, year, image_url, status, is_featured) VALUES
(1, 'Corporate Headquarters', 'Commercial', 'Lagos, Nigeria', '2024', 'https://images.unsplash.com/photo-1486325212027-8081e485255e?auto=format&fit=crop&w=700&q=80', 'Completed', true),
(2, 'Luxury Villa Interior', 'Interior', 'Abuja, Nigeria', '2024', 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=700&q=80', 'Completed', true),
(3, 'Green Estate Development', 'Residential', 'Delta State', '2025', 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=700&q=80', 'Ongoing', true),
(4, 'Shopping Mall Complex', 'Commercial', 'Port Harcourt', '2023', 'https://images.unsplash.com/photo-1555636222-cae831e670b3?auto=format&fit=crop&w=700&q=80', 'Completed', false),
(5, 'Executive Office Fit-Out', 'Interior', 'Lagos, Nigeria', '2024', 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=700&q=80', 'Completed', false),
(6, 'Riverside Tower', 'Residential', 'Lagos Island', '2025', 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=700&q=80', 'Ongoing', false)
ON CONFLICT DO NOTHING;

-- ============================================================
-- GALLERY IMAGES
-- ============================================================
CREATE TABLE IF NOT EXISTS gallery_images (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sort_order INT DEFAULT 0,
  image_url TEXT NOT NULL,
  caption TEXT,
  category TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO gallery_images (sort_order, image_url, category) VALUES
(1, 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=600&q=80', 'Construction'),
(2, 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=600&q=80', 'Interior'),
(3, 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=600&q=80', 'Residential'),
(4, 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=600&q=80', 'Commercial'),
(5, 'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?w=600&q=80', 'Construction'),
(6, 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=600&q=80', 'Residential'),
(7, 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=600&q=80', 'Architecture'),
(8, 'https://images.unsplash.com/photo-1486325212027-8081e485255e?w=600&q=80', 'Commercial')
ON CONFLICT DO NOTHING;

-- ============================================================
-- TEAM MEMBERS
-- ============================================================
CREATE TABLE IF NOT EXISTS team_members (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sort_order INT DEFAULT 0,
  name TEXT NOT NULL,
  role TEXT,
  bio TEXT,
  image_url TEXT,
  linkedin_url TEXT,
  twitter_url TEXT,
  instagram_url TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO team_members (sort_order, name, role, image_url) VALUES
(1, 'Adaeze Okonkwo', 'CEO & Founder', 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=400&q=80'),
(2, 'Chukwuemeka Eze', 'Chief Operations Officer', 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=400&q=80'),
(3, 'Ngozi Adeleke', 'Head of Design', 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80'),
(4, 'Babatunde Adesanya', 'Chief Engineer', 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=400&q=80')
ON CONFLICT DO NOTHING;

-- ============================================================
-- TESTIMONIALS
-- ============================================================
CREATE TABLE IF NOT EXISTS testimonials (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sort_order INT DEFAULT 0,
  author_name TEXT NOT NULL,
  author_role TEXT,
  author_image_url TEXT,
  content TEXT NOT NULL,
  rating INT DEFAULT 5,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO testimonials (sort_order, author_name, author_role, author_image_url, content) VALUES
(1, 'Chief Okonkwo', 'Property Developer, Lagos', 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=100&q=80', 'Jill Global Services exceeded our expectations in every way. Their professionalism, attention to detail, and timely delivery transformed our vision into a stunning reality.'),
(2, 'Mrs. Adebayo', 'Business Owner, Abuja', 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=100&q=80', 'The team expertise in construction and interior design made our office project completely seamless. The result is beyond what we imagined. Highly recommended.'),
(3, 'Engr. Samuel Dike', 'Real Estate Investor, PH', 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=100&q=80', 'Transparent pricing, impeccable craftsmanship, and a team that truly listens. Jill Global handled our estate development with incredible professionalism from day one.')
ON CONFLICT DO NOTHING;

-- ============================================================
-- BLOG POSTS
-- ============================================================
CREATE TABLE IF NOT EXISTS blog_posts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  slug TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  excerpt TEXT,
  content TEXT,
  category TEXT,
  author TEXT DEFAULT 'Editorial Team',
  cover_image_url TEXT,
  read_time TEXT DEFAULT '5 min read',
  is_published BOOLEAN DEFAULT true,
  published_at TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO blog_posts (slug, title, excerpt, category, cover_image_url, read_time, published_at) VALUES
('future-of-construction-nigeria', 'The Future of Construction in Nigeria', 'Exploring emerging trends, technologies, and opportunities shaping the Nigerian construction industry in 2025 and beyond.', 'Industry Insights', 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=600&q=80', '5 min read', NOW() - INTERVAL '15 days'),
('smart-home-design', 'Smart Home Design: What You Need to Know', 'A comprehensive guide to integrating smart technology into modern home designs for enhanced comfort and efficiency.', 'Interior Design', 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=600&q=80', '7 min read', NOW() - INTERVAL '20 days'),
('real-estate-investment', 'Real Estate Investment in Emerging Nigerian Markets', 'Key strategies for maximizing returns on real estate investments in Nigeria rapidly growing property market.', 'Real Estate', 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=600&q=80', '8 min read', NOW() - INTERVAL '32 days'),
('sustainable-building', 'Sustainable Building Practices for the Future', 'How eco-friendly construction methods are reshaping the industry and creating lasting environmental impact.', 'Sustainability', 'https://images.unsplash.com/photo-1466611653911-95081537e5b7?w=600&q=80', '6 min read', NOW() - INTERVAL '45 days')
ON CONFLICT DO NOTHING;

-- ============================================================
-- FAQ ITEMS
-- ============================================================
CREATE TABLE IF NOT EXISTS faq_items (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sort_order INT DEFAULT 0,
  question TEXT NOT NULL,
  answer TEXT NOT NULL,
  category TEXT DEFAULT 'General',
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO faq_items (sort_order, question, answer) VALUES
(1, 'What services does Jill Global Services Ltd provide?', 'We offer comprehensive services including construction & engineering, interior design & fit-out, property development & real estate advisory, technical & digital solutions, and general contracting — all under one roof for seamless integrated delivery.'),
(2, 'Do you handle turnkey projects?', 'Yes, turnkey delivery is a core speciality. We manage projects from initial concept and design through execution and final handover, ensuring seamless coordination at every stage.'),
(3, 'How do I start a project with your company?', 'Simply contact us via our website form, call +234 706 502 4741, or message us on WhatsApp. Our team will schedule a consultation to discuss your requirements and develop a customized proposal — usually within 48 hours.'),
(4, 'Do you work with corporate clients and individuals?', 'Absolutely. We serve corporate organizations, property developers, government agencies, and private individuals. Our solutions are tailored to the specific needs, scale, and budget of each client.'),
(5, 'What is your typical project timeline?', 'Timelines vary based on scope and complexity. During our consultation, we provide detailed project schedules with clear milestones. We are known for on-time delivery without compromising quality.'),
(6, 'Do you provide payment plans?', 'Yes. We offer flexible milestone-based payment structures. During the consultation phase, we will agree on terms that work for both parties while ensuring project continuity.')
ON CONFLICT DO NOTHING;

-- ============================================================
-- CAREERS / JOB OPENINGS
-- ============================================================
CREATE TABLE IF NOT EXISTS job_openings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sort_order INT DEFAULT 0,
  department TEXT,
  title TEXT NOT NULL,
  location TEXT,
  job_type TEXT DEFAULT 'Full-time',
  description TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO job_openings (sort_order, department, title, location, job_type, description) VALUES
(1, 'Construction', 'Senior Project Manager', 'Lagos, Nigeria', 'Full-time', 'Lead and manage large-scale construction projects from inception to completion, ensuring quality, budget, and timeline adherence.'),
(2, 'Design', 'Interior Designer', 'Abuja, Nigeria', 'Full-time', 'Create innovative, functional interior design solutions for high-end residential and commercial clients. 3D rendering proficiency required.'),
(3, 'Engineering', 'Civil Engineer', 'Delta State', 'Full-time', 'Design and oversee civil engineering projects focusing on structural integrity, safety, and compliance with Nigerian building standards.')
ON CONFLICT DO NOTHING;

-- ============================================================
-- LEADS (Contact Form Submissions)
-- ============================================================
CREATE TABLE IF NOT EXISTS leads (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT,
  email TEXT,
  phone TEXT,
  service TEXT,
  location TEXT,
  budget TEXT,
  message TEXT,
  source TEXT DEFAULT 'Website',
  status TEXT DEFAULT 'New',
  airtable_id TEXT,
  whatsapp_sent BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- NEWSLETTER SUBSCRIBERS
-- ============================================================
CREATE TABLE IF NOT EXISTS newsletter_subscribers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email TEXT UNIQUE NOT NULL,
  is_active BOOLEAN DEFAULT true,
  subscribed_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- ENABLE ROW LEVEL SECURITY
-- ============================================================
ALTER TABLE leads ENABLE ROW LEVEL SECURITY;
ALTER TABLE newsletter_subscribers ENABLE ROW LEVEL SECURITY;
ALTER TABLE site_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE hero_section ENABLE ROW LEVEL SECURITY;
ALTER TABLE about_section ENABLE ROW LEVEL SECURITY;
ALTER TABLE services ENABLE ROW LEVEL SECURITY;
ALTER TABLE portfolio_projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE gallery_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE team_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE testimonials ENABLE ROW LEVEL SECURITY;
ALTER TABLE blog_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE faq_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE job_openings ENABLE ROW LEVEL SECURITY;

-- Public read access for content tables
CREATE POLICY "public_read_settings" ON site_settings FOR SELECT TO anon USING (true);
CREATE POLICY "public_read_hero" ON hero_section FOR SELECT TO anon USING (true);
CREATE POLICY "public_read_about" ON about_section FOR SELECT TO anon USING (true);
CREATE POLICY "public_read_services" ON services FOR SELECT TO anon USING (is_active = true);
CREATE POLICY "public_read_portfolio" ON portfolio_projects FOR SELECT TO anon USING (is_active = true);
CREATE POLICY "public_read_gallery" ON gallery_images FOR SELECT TO anon USING (is_active = true);
CREATE POLICY "public_read_team" ON team_members FOR SELECT TO anon USING (is_active = true);
CREATE POLICY "public_read_testimonials" ON testimonials FOR SELECT TO anon USING (is_active = true);
CREATE POLICY "public_read_blog" ON blog_posts FOR SELECT TO anon USING (is_published = true);
CREATE POLICY "public_read_faq" ON faq_items FOR SELECT TO anon USING (is_active = true);
CREATE POLICY "public_read_jobs" ON job_openings FOR SELECT TO anon USING (is_active = true);

-- Public write for leads and newsletter
CREATE POLICY "public_insert_leads" ON leads FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "public_insert_newsletter" ON newsletter_subscribers FOR INSERT TO anon WITH CHECK (true);

-- Service role full access (for admin operations)
CREATE POLICY "service_all_settings" ON site_settings FOR ALL TO service_role USING (true);
CREATE POLICY "service_all_hero" ON hero_section FOR ALL TO service_role USING (true);
CREATE POLICY "service_all_about" ON about_section FOR ALL TO service_role USING (true);
CREATE POLICY "service_all_services" ON services FOR ALL TO service_role USING (true);
CREATE POLICY "service_all_portfolio" ON portfolio_projects FOR ALL TO service_role USING (true);
CREATE POLICY "service_all_gallery" ON gallery_images FOR ALL TO service_role USING (true);
CREATE POLICY "service_all_team" ON team_members FOR ALL TO service_role USING (true);
CREATE POLICY "service_all_testimonials" ON testimonials FOR ALL TO service_role USING (true);
CREATE POLICY "service_all_blog" ON blog_posts FOR ALL TO service_role USING (true);
CREATE POLICY "service_all_faq" ON faq_items FOR ALL TO service_role USING (true);
CREATE POLICY "service_all_jobs" ON job_openings FOR ALL TO service_role USING (true);
CREATE POLICY "service_all_leads" ON leads FOR ALL TO service_role USING (true);
CREATE POLICY "service_all_newsletter" ON newsletter_subscribers FOR ALL TO service_role USING (true);

-- ============================================================
-- STORAGE BUCKET FOR IMAGES
-- ============================================================
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('site-images', 'site-images', true, 10485760, ARRAY['image/jpeg','image/png','image/webp','image/gif','image/svg+xml'])
ON CONFLICT DO NOTHING;

CREATE POLICY "public_read_images" ON storage.objects FOR SELECT TO anon USING (bucket_id = 'site-images');
CREATE POLICY "service_upload_images" ON storage.objects FOR INSERT TO service_role WITH CHECK (bucket_id = 'site-images');
CREATE POLICY "service_delete_images" ON storage.objects FOR DELETE TO service_role USING (bucket_id = 'site-images');
