/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx}',
    './src/components/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        green: { DEFAULT: '#005C3D', mid: '#1a7a54', deep: '#003d28', lt: '#e6f4ee' },
        gold: { DEFAULT: '#C89A1C', lt: '#e8b83a', deep: '#a07810' },
      },
      fontFamily: {
        serif: ['"Playfair Display"', 'serif'],
        sans: ['Outfit', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
