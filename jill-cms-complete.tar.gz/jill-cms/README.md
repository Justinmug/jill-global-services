# Jill Global Services - CMS Website

## Architecture

```
Frontend (Next.js 14) ─── Supabase (Database + Storage)
                      ─── Airtable (CRM)
                      ─── n8n (WhatsApp Automation)
Admin Dashboard (/admin) ─── Full CMS: edit all content, upload images
```

## Setup

### 1. Supabase Setup
1. Go to your Supabase project (kidmuqqwccmcgjoecxkt)
2. Open SQL Editor
3. Run the entire contents of `supabase-schema.sql`
4. This creates all tables, RLS policies, and the `site-images` storage bucket

### 2. Environment Variables
Update `.env.local` with your actual keys (already pre-filled with known values)

### 3. n8n Webhook Setup
In your n8n at flow.jillglobalservices.com, create a webhook trigger at:
- Path: `/contact-form` — receives new lead data
- The payload includes: `{ event, payload: { name, email, phone, service, message, ... } }`
- Connect this to your WhatsApp notification flow

### 4. Deploy to VPS

```bash
# On your local machine, upload the archive
scp jill-cms-complete.tar.gz root@31.97.57.116:/tmp/

# SSH in and deploy
ssh root@31.97.57.116
cd /tmp
tar -xzf jill-cms-complete.tar.gz
cp -r jill-cms/* /docker/jill-global/
cd /docker/jill-global
docker compose build --no-cache
docker compose up -d
```

## Admin Dashboard

Visit: `https://jillglobalservices.com/admin`
Password: (set in ADMIN_PASSWORD env var)

### What you can edit:
- **Logo & Branding** — company logo, name, tagline
- **Hero Section** — headline, subtext, background image, stats
- **About Page** — story, vision, mission, images
- **Services** — add/edit/delete services with images
- **Portfolio** — manage projects with photos, categories, status
- **Gallery** — upload and manage gallery images
- **Team** — team members with photos and social links
- **Testimonials** — client reviews
- **Blog Posts** — full blog management with publish/draft
- **FAQ** — questions and answers
- **Careers** — job openings
- **Social Media** — Instagram, Facebook, LinkedIn, Twitter, YouTube, TikTok
- **Contact Info** — phone, WhatsApp, email, address
- **Leads CRM** — all contact form submissions with Airtable sync status
- **Automation** — n8n webhook URLs

## Automation Flow

1. Visitor fills contact form → `POST /api/leads`
2. Lead saved to Supabase `leads` table
3. Lead synced to Airtable CRM (async)
4. n8n webhook triggered at `N8N_CONTACT_WEBHOOK_URL`
5. n8n sends WhatsApp notification to your number
6. Lead shows in Admin dashboard with Airtable sync status
